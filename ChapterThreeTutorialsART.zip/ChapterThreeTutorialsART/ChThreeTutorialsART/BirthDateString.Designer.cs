﻿namespace ChThreeTutorialsART
{
    partial class BirthDateString
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DayOfWeekPromptLB = new System.Windows.Forms.Label();
            this.MonthPromptLB = new System.Windows.Forms.Label();
            this.DayOfMonthPromptLB = new System.Windows.Forms.Label();
            this.YearPromptLB = new System.Windows.Forms.Label();
            this.dayOfWeekTB = new System.Windows.Forms.TextBox();
            this.monthTB = new System.Windows.Forms.TextBox();
            this.dayOfMonthTB = new System.Windows.Forms.TextBox();
            this.yearTB = new System.Windows.Forms.TextBox();
            this.dateOutputLB = new System.Windows.Forms.Label();
            this.showDateBTN = new System.Windows.Forms.Button();
            this.clearBTN = new System.Windows.Forms.Button();
            this.exitBTN = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // DayOfWeekPromptLB
            // 
            this.DayOfWeekPromptLB.AutoSize = true;
            this.DayOfWeekPromptLB.Location = new System.Drawing.Point(32, 18);
            this.DayOfWeekPromptLB.Name = "DayOfWeekPromptLB";
            this.DayOfWeekPromptLB.Size = new System.Drawing.Size(129, 13);
            this.DayOfWeekPromptLB.TabIndex = 0;
            this.DayOfWeekPromptLB.Text = "Enter the day of the week";
            // 
            // MonthPromptLB
            // 
            this.MonthPromptLB.AutoSize = true;
            this.MonthPromptLB.Location = new System.Drawing.Point(32, 67);
            this.MonthPromptLB.Name = "MonthPromptLB";
            this.MonthPromptLB.Size = new System.Drawing.Size(141, 13);
            this.MonthPromptLB.TabIndex = 1;
            this.MonthPromptLB.Text = "Enter the name of the month";
            // 
            // DayOfMonthPromptLB
            // 
            this.DayOfMonthPromptLB.AutoSize = true;
            this.DayOfMonthPromptLB.Location = new System.Drawing.Point(32, 116);
            this.DayOfMonthPromptLB.Name = "DayOfMonthPromptLB";
            this.DayOfMonthPromptLB.Size = new System.Drawing.Size(172, 13);
            this.DayOfMonthPromptLB.TabIndex = 2;
            this.DayOfMonthPromptLB.Text = "Enter the numeric day of the month";
            // 
            // YearPromptLB
            // 
            this.YearPromptLB.AutoSize = true;
            this.YearPromptLB.Location = new System.Drawing.Point(32, 165);
            this.YearPromptLB.Name = "YearPromptLB";
            this.YearPromptLB.Size = new System.Drawing.Size(73, 13);
            this.YearPromptLB.TabIndex = 3;
            this.YearPromptLB.Text = "Enter the year";
            // 
            // dayOfWeekTB
            // 
            this.dayOfWeekTB.Location = new System.Drawing.Point(265, 18);
            this.dayOfWeekTB.Name = "dayOfWeekTB";
            this.dayOfWeekTB.Size = new System.Drawing.Size(100, 20);
            this.dayOfWeekTB.TabIndex = 4;
            // 
            // monthTB
            // 
            this.monthTB.Location = new System.Drawing.Point(265, 67);
            this.monthTB.Name = "monthTB";
            this.monthTB.Size = new System.Drawing.Size(100, 20);
            this.monthTB.TabIndex = 5;
            // 
            // dayOfMonthTB
            // 
            this.dayOfMonthTB.Location = new System.Drawing.Point(265, 116);
            this.dayOfMonthTB.Name = "dayOfMonthTB";
            this.dayOfMonthTB.Size = new System.Drawing.Size(100, 20);
            this.dayOfMonthTB.TabIndex = 6;
            // 
            // yearTB
            // 
            this.yearTB.Location = new System.Drawing.Point(265, 157);
            this.yearTB.Name = "yearTB";
            this.yearTB.Size = new System.Drawing.Size(100, 20);
            this.yearTB.TabIndex = 7;
            // 
            // dateOutputLB
            // 
            this.dateOutputLB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dateOutputLB.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateOutputLB.Location = new System.Drawing.Point(13, 238);
            this.dateOutputLB.Name = "dateOutputLB";
            this.dateOutputLB.Size = new System.Drawing.Size(352, 47);
            this.dateOutputLB.TabIndex = 8;
            this.dateOutputLB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // showDateBTN
            // 
            this.showDateBTN.Location = new System.Drawing.Point(13, 301);
            this.showDateBTN.Name = "showDateBTN";
            this.showDateBTN.Size = new System.Drawing.Size(116, 41);
            this.showDateBTN.TabIndex = 9;
            this.showDateBTN.Text = "SHOW DATE";
            this.showDateBTN.UseVisualStyleBackColor = true;
            this.showDateBTN.Click += new System.EventHandler(this.showDateBTN_Click);
            // 
            // clearBTN
            // 
            this.clearBTN.Location = new System.Drawing.Point(131, 301);
            this.clearBTN.Name = "clearBTN";
            this.clearBTN.Size = new System.Drawing.Size(116, 41);
            this.clearBTN.TabIndex = 10;
            this.clearBTN.Text = "CLEAR";
            this.clearBTN.UseVisualStyleBackColor = true;
            this.clearBTN.Click += new System.EventHandler(this.clearBTN_Click);
            // 
            // exitBTN
            // 
            this.exitBTN.Location = new System.Drawing.Point(249, 301);
            this.exitBTN.Name = "exitBTN";
            this.exitBTN.Size = new System.Drawing.Size(116, 41);
            this.exitBTN.TabIndex = 11;
            this.exitBTN.Text = "EXIT";
            this.exitBTN.UseVisualStyleBackColor = true;
            this.exitBTN.Click += new System.EventHandler(this.exitBTN_Click);
            // 
            // BirthDateString
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(387, 367);
            this.Controls.Add(this.exitBTN);
            this.Controls.Add(this.clearBTN);
            this.Controls.Add(this.showDateBTN);
            this.Controls.Add(this.dateOutputLB);
            this.Controls.Add(this.yearTB);
            this.Controls.Add(this.dayOfMonthTB);
            this.Controls.Add(this.monthTB);
            this.Controls.Add(this.dayOfWeekTB);
            this.Controls.Add(this.YearPromptLB);
            this.Controls.Add(this.DayOfMonthPromptLB);
            this.Controls.Add(this.MonthPromptLB);
            this.Controls.Add(this.DayOfWeekPromptLB);
            this.Name = "BirthDateString";
            this.Text = "Bith Date String";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label DayOfWeekPromptLB;
        private System.Windows.Forms.Label MonthPromptLB;
        private System.Windows.Forms.Label DayOfMonthPromptLB;
        private System.Windows.Forms.Label YearPromptLB;
        private System.Windows.Forms.TextBox dayOfWeekTB;
        private System.Windows.Forms.TextBox monthTB;
        private System.Windows.Forms.TextBox dayOfMonthTB;
        private System.Windows.Forms.TextBox yearTB;
        private System.Windows.Forms.Label dateOutputLB;
        private System.Windows.Forms.Button showDateBTN;
        private System.Windows.Forms.Button clearBTN;
        private System.Windows.Forms.Button exitBTN;
    }
}

