﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChThreeTutorialsART
{
    public partial class BirthDateString : Form
    {
        public BirthDateString()
        {
            InitializeComponent();
        }

        private void showDateBTN_Click(object sender, EventArgs e)
        {
            try
            {
                //declare a string variable
                string output;

                //concatenate the input and build teh output string
                output = dayOfWeekTB.Text + ", " +
                    monthTB.Text + "  " +
                    dayOfMonthTB.Text + ", " +
                    yearTB.Text;

                // display the output string in the label control
                dateOutputLB.Text = output;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        
        }

        private void clearBTN_Click(object sender, EventArgs e)
        {
            // clear the textboxes.
            dayOfWeekTB.Text = "";
            monthTB.Text = "";
            dayOfMonthTB.Text = "";
            yearTB.Text = "";

            //clear teh dateOutputlabel control
            dateOutputLB.Text = "";

        }

        private void exitBTN_Click(object sender, EventArgs e)
        {
            //close the form.
            this.Close();

        }
    }
}
