﻿namespace FuelEconomy
{
    partial class FuelEconomy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.milesPromptLB = new System.Windows.Forms.Label();
            this.gasPromptLB = new System.Windows.Forms.Label();
            this.outputDescriptionLB = new System.Windows.Forms.Label();
            this.mpgLB = new System.Windows.Forms.Label();
            this.calculateBTN = new System.Windows.Forms.Button();
            this.exitBTN = new System.Windows.Forms.Button();
            this.milesTB = new System.Windows.Forms.TextBox();
            this.gallonsTB = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // milesPromptLB
            // 
            this.milesPromptLB.AutoSize = true;
            this.milesPromptLB.Location = new System.Drawing.Point(12, 16);
            this.milesPromptLB.Name = "milesPromptLB";
            this.milesPromptLB.Size = new System.Drawing.Size(161, 13);
            this.milesPromptLB.TabIndex = 0;
            this.milesPromptLB.Text = "Enter the number of miles driven:";
            // 
            // gasPromptLB
            // 
            this.gasPromptLB.AutoSize = true;
            this.gasPromptLB.Location = new System.Drawing.Point(12, 61);
            this.gasPromptLB.Name = "gasPromptLB";
            this.gasPromptLB.Size = new System.Drawing.Size(147, 13);
            this.gasPromptLB.TabIndex = 1;
            this.gasPromptLB.Text = "Enter the gallons of gas used:";
            // 
            // outputDescriptionLB
            // 
            this.outputDescriptionLB.AutoSize = true;
            this.outputDescriptionLB.Location = new System.Drawing.Point(12, 106);
            this.outputDescriptionLB.Name = "outputDescriptionLB";
            this.outputDescriptionLB.Size = new System.Drawing.Size(84, 13);
            this.outputDescriptionLB.TabIndex = 2;
            this.outputDescriptionLB.Text = "Your car\'s MPG:";
            // 
            // mpgLB
            // 
            this.mpgLB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mpgLB.Location = new System.Drawing.Point(179, 101);
            this.mpgLB.Name = "mpgLB";
            this.mpgLB.Size = new System.Drawing.Size(100, 23);
            this.mpgLB.TabIndex = 3;
            this.mpgLB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // calculateBTN
            // 
            this.calculateBTN.Location = new System.Drawing.Point(30, 195);
            this.calculateBTN.Name = "calculateBTN";
            this.calculateBTN.Size = new System.Drawing.Size(94, 54);
            this.calculateBTN.TabIndex = 4;
            this.calculateBTN.Text = "CALCULATE MPG";
            this.calculateBTN.UseVisualStyleBackColor = true;
            this.calculateBTN.Click += new System.EventHandler(this.calculateBTN_Click);
            // 
            // exitBTN
            // 
            this.exitBTN.Location = new System.Drawing.Point(182, 195);
            this.exitBTN.Name = "exitBTN";
            this.exitBTN.Size = new System.Drawing.Size(94, 54);
            this.exitBTN.TabIndex = 5;
            this.exitBTN.Text = "EXIT";
            this.exitBTN.UseVisualStyleBackColor = true;
            this.exitBTN.Click += new System.EventHandler(this.exitBTN_Click);
            // 
            // milesTB
            // 
            this.milesTB.Location = new System.Drawing.Point(179, 13);
            this.milesTB.Name = "milesTB";
            this.milesTB.Size = new System.Drawing.Size(100, 20);
            this.milesTB.TabIndex = 6;
            // 
            // gallonsTB
            // 
            this.gallonsTB.Location = new System.Drawing.Point(179, 58);
            this.gallonsTB.Name = "gallonsTB";
            this.gallonsTB.Size = new System.Drawing.Size(100, 20);
            this.gallonsTB.TabIndex = 7;
            // 
            // FuelEconomy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(315, 261);
            this.Controls.Add(this.gallonsTB);
            this.Controls.Add(this.milesTB);
            this.Controls.Add(this.exitBTN);
            this.Controls.Add(this.calculateBTN);
            this.Controls.Add(this.mpgLB);
            this.Controls.Add(this.outputDescriptionLB);
            this.Controls.Add(this.gasPromptLB);
            this.Controls.Add(this.milesPromptLB);
            this.Name = "FuelEconomy";
            this.Text = "Fuel Economy";
            this.Load += new System.EventHandler(this.FuelEconomy_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label milesPromptLB;
        private System.Windows.Forms.Label gasPromptLB;
        private System.Windows.Forms.Label outputDescriptionLB;
        private System.Windows.Forms.Label mpgLB;
        private System.Windows.Forms.Button calculateBTN;
        private System.Windows.Forms.Button exitBTN;
        private System.Windows.Forms.TextBox milesTB;
        private System.Windows.Forms.TextBox gallonsTB;
    }
}

