﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FuelEconomy
{
    public partial class FuelEconomy : Form
    {
        public FuelEconomy()
        {
            InitializeComponent();
        }

        private void calculateBTN_Click(object sender, EventArgs e)
        {
            try
            {
                double miles;   //to hold miles driven
                double gallons; //to hold gallons used
                double mpg;     //to hold MPG

                //get the mile driven and assig it to
                //the miles variable.
                miles = double.Parse(milesTB.Text);

                //get the gallons used and assign it to
                //the gallons variable
                gallons = double.Parse(gallonsTB.Text);

                //calculate MPG.
                mpg = miles / gallons;

                //display the mpg in the mpglb control
                mpgLB.Text = mpg.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
                
        }

        private void exitBTN_Click(object sender, EventArgs e)
        {
            //close the form
            this.Close();
        }

        private void FuelEconomy_Load(object sender, EventArgs e)
        {

        }
    }
}
