﻿namespace ProgrammingProblem1
{
    partial class NameFormater
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.firstNameTB = new System.Windows.Forms.TextBox();
            this.middleNameTB = new System.Windows.Forms.TextBox();
            this.lastNameTB = new System.Windows.Forms.TextBox();
            this.titleCB = new System.Windows.Forms.ComboBox();
            this.firstNameLB = new System.Windows.Forms.Label();
            this.middleNameLB = new System.Windows.Forms.Label();
            this.lastNameLB = new System.Windows.Forms.Label();
            this.titleLB = new System.Windows.Forms.Label();
            this.NameLB = new System.Windows.Forms.Label();
            this.option1BTN = new System.Windows.Forms.Button();
            this.option2BTN = new System.Windows.Forms.Button();
            this.option3BTN = new System.Windows.Forms.Button();
            this.option4BTN = new System.Windows.Forms.Button();
            this.option5BTN = new System.Windows.Forms.Button();
            this.option6BTN = new System.Windows.Forms.Button();
            this.exitBTN = new System.Windows.Forms.Button();
            this.clearBTN = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // firstNameTB
            // 
            this.firstNameTB.Location = new System.Drawing.Point(176, 15);
            this.firstNameTB.Name = "firstNameTB";
            this.firstNameTB.Size = new System.Drawing.Size(136, 20);
            this.firstNameTB.TabIndex = 0;
            // 
            // middleNameTB
            // 
            this.middleNameTB.Location = new System.Drawing.Point(176, 52);
            this.middleNameTB.Name = "middleNameTB";
            this.middleNameTB.Size = new System.Drawing.Size(136, 20);
            this.middleNameTB.TabIndex = 1;
            // 
            // lastNameTB
            // 
            this.lastNameTB.Location = new System.Drawing.Point(176, 89);
            this.lastNameTB.Name = "lastNameTB";
            this.lastNameTB.Size = new System.Drawing.Size(136, 20);
            this.lastNameTB.TabIndex = 2;
            // 
            // titleCB
            // 
            this.titleCB.FormattingEnabled = true;
            this.titleCB.Items.AddRange(new object[] {
            "Dr.",
            "Mr.",
            "Mrs.",
            "Ms."});
            this.titleCB.Location = new System.Drawing.Point(176, 126);
            this.titleCB.Name = "titleCB";
            this.titleCB.Size = new System.Drawing.Size(136, 21);
            this.titleCB.TabIndex = 3;
            // 
            // firstNameLB
            // 
            this.firstNameLB.AutoSize = true;
            this.firstNameLB.Location = new System.Drawing.Point(30, 18);
            this.firstNameLB.Name = "firstNameLB";
            this.firstNameLB.Size = new System.Drawing.Size(111, 13);
            this.firstNameLB.TabIndex = 11;
            this.firstNameLB.Text = "Enter your First Name:";
            // 
            // middleNameLB
            // 
            this.middleNameLB.AutoSize = true;
            this.middleNameLB.Location = new System.Drawing.Point(30, 55);
            this.middleNameLB.Name = "middleNameLB";
            this.middleNameLB.Size = new System.Drawing.Size(123, 13);
            this.middleNameLB.TabIndex = 12;
            this.middleNameLB.Text = "Enter your Middle Name:";
            // 
            // lastNameLB
            // 
            this.lastNameLB.AutoSize = true;
            this.lastNameLB.Location = new System.Drawing.Point(30, 92);
            this.lastNameLB.Name = "lastNameLB";
            this.lastNameLB.Size = new System.Drawing.Size(112, 13);
            this.lastNameLB.TabIndex = 13;
            this.lastNameLB.Text = "Enter your Last Name:";
            // 
            // titleLB
            // 
            this.titleLB.AutoSize = true;
            this.titleLB.Location = new System.Drawing.Point(30, 129);
            this.titleLB.Name = "titleLB";
            this.titleLB.Size = new System.Drawing.Size(77, 13);
            this.titleLB.TabIndex = 14;
            this.titleLB.Text = "Pick your Title:";
            // 
            // NameLB
            // 
            this.NameLB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.NameLB.Location = new System.Drawing.Point(33, 172);
            this.NameLB.Name = "NameLB";
            this.NameLB.Size = new System.Drawing.Size(279, 23);
            this.NameLB.TabIndex = 15;
            this.NameLB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // option1BTN
            // 
            this.option1BTN.Location = new System.Drawing.Point(50, 216);
            this.option1BTN.Name = "option1BTN";
            this.option1BTN.Size = new System.Drawing.Size(75, 23);
            this.option1BTN.TabIndex = 3;
            this.option1BTN.Text = "Option 1";
            this.option1BTN.UseVisualStyleBackColor = true;
            this.option1BTN.Click += new System.EventHandler(this.option1BTN_Click);
            // 
            // option2BTN
            // 
            this.option2BTN.Location = new System.Drawing.Point(132, 215);
            this.option2BTN.Name = "option2BTN";
            this.option2BTN.Size = new System.Drawing.Size(75, 23);
            this.option2BTN.TabIndex = 4;
            this.option2BTN.Text = "Option 2";
            this.option2BTN.UseVisualStyleBackColor = true;
            this.option2BTN.Click += new System.EventHandler(this.option2BTN_Click);
            // 
            // option3BTN
            // 
            this.option3BTN.Location = new System.Drawing.Point(214, 215);
            this.option3BTN.Name = "option3BTN";
            this.option3BTN.Size = new System.Drawing.Size(75, 23);
            this.option3BTN.TabIndex = 5;
            this.option3BTN.Text = "Option 3";
            this.option3BTN.UseVisualStyleBackColor = true;
            this.option3BTN.Click += new System.EventHandler(this.option3BTN_Click);
            // 
            // option4BTN
            // 
            this.option4BTN.Location = new System.Drawing.Point(50, 245);
            this.option4BTN.Name = "option4BTN";
            this.option4BTN.Size = new System.Drawing.Size(75, 23);
            this.option4BTN.TabIndex = 6;
            this.option4BTN.Text = "Option 4";
            this.option4BTN.UseVisualStyleBackColor = true;
            this.option4BTN.Click += new System.EventHandler(this.option4BTN_Click);
            // 
            // option5BTN
            // 
            this.option5BTN.Location = new System.Drawing.Point(132, 245);
            this.option5BTN.Name = "option5BTN";
            this.option5BTN.Size = new System.Drawing.Size(75, 23);
            this.option5BTN.TabIndex = 7;
            this.option5BTN.Text = "Option 5";
            this.option5BTN.UseVisualStyleBackColor = true;
            this.option5BTN.Click += new System.EventHandler(this.option5BTN_Click);
            // 
            // option6BTN
            // 
            this.option6BTN.Location = new System.Drawing.Point(214, 245);
            this.option6BTN.Name = "option6BTN";
            this.option6BTN.Size = new System.Drawing.Size(75, 23);
            this.option6BTN.TabIndex = 8;
            this.option6BTN.Text = "Option 6";
            this.option6BTN.UseVisualStyleBackColor = true;
            this.option6BTN.Click += new System.EventHandler(this.option6BTN_Click);
            // 
            // exitBTN
            // 
            this.exitBTN.Location = new System.Drawing.Point(50, 294);
            this.exitBTN.Name = "exitBTN";
            this.exitBTN.Size = new System.Drawing.Size(75, 23);
            this.exitBTN.TabIndex = 9;
            this.exitBTN.Text = "E&XIT";
            this.exitBTN.UseVisualStyleBackColor = true;
            this.exitBTN.Click += new System.EventHandler(this.exitBTN_Click);
            // 
            // clearBTN
            // 
            this.clearBTN.Location = new System.Drawing.Point(214, 293);
            this.clearBTN.Name = "clearBTN";
            this.clearBTN.Size = new System.Drawing.Size(75, 23);
            this.clearBTN.TabIndex = 10;
            this.clearBTN.Text = "CLEAR";
            this.clearBTN.UseVisualStyleBackColor = true;
            this.clearBTN.Click += new System.EventHandler(this.clearBTN_Click);
            // 
            // NameFormater
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(343, 339);
            this.Controls.Add(this.clearBTN);
            this.Controls.Add(this.exitBTN);
            this.Controls.Add(this.option6BTN);
            this.Controls.Add(this.option5BTN);
            this.Controls.Add(this.option4BTN);
            this.Controls.Add(this.option3BTN);
            this.Controls.Add(this.option2BTN);
            this.Controls.Add(this.option1BTN);
            this.Controls.Add(this.NameLB);
            this.Controls.Add(this.titleLB);
            this.Controls.Add(this.lastNameLB);
            this.Controls.Add(this.middleNameLB);
            this.Controls.Add(this.firstNameLB);
            this.Controls.Add(this.titleCB);
            this.Controls.Add(this.lastNameTB);
            this.Controls.Add(this.middleNameTB);
            this.Controls.Add(this.firstNameTB);
            this.Name = "NameFormater";
            this.Text = "Name Formatter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox firstNameTB;
        private System.Windows.Forms.TextBox middleNameTB;
        private System.Windows.Forms.TextBox lastNameTB;
        private System.Windows.Forms.ComboBox titleCB;
        private System.Windows.Forms.Label firstNameLB;
        private System.Windows.Forms.Label middleNameLB;
        private System.Windows.Forms.Label lastNameLB;
        private System.Windows.Forms.Label titleLB;
        private System.Windows.Forms.Label NameLB;
        private System.Windows.Forms.Button option1BTN;
        private System.Windows.Forms.Button option2BTN;
        private System.Windows.Forms.Button option3BTN;
        private System.Windows.Forms.Button option4BTN;
        private System.Windows.Forms.Button option5BTN;
        private System.Windows.Forms.Button option6BTN;
        private System.Windows.Forms.Button exitBTN;
        private System.Windows.Forms.Button clearBTN;
    }
}

