﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProgrammingProblem1
{
    public partial class NameFormater : Form
    {
        public NameFormater()
        {
            InitializeComponent();
        }

        private void option1BTN_Click(object sender, EventArgs e)
        {
            try
            {
                //Declare a string Variable to hold the name.
                String Name;

                //combine the name 
                //result to the name variable

                Name = titleCB.Text + " " + firstNameTB.Text + " "
                    + middleNameTB.Text + " " + lastNameTB.Text;

                NameLB.Text = Name;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void option2BTN_Click(object sender, EventArgs e)
        {
            //Declare a string Variable to hold the name.
            String Name;

            //combine the name 
            //result to the name variable

            Name = firstNameTB.Text + " " + middleNameTB.Text + " " + lastNameTB.Text;

            NameLB.Text = Name;
        }

        private void option3BTN_Click(object sender, EventArgs e)
        {
            //Declare a string Variable to hold the name.
            String Name;

            //combine the name 
            //result to the name variable
            Name = firstNameTB.Text + " " + lastNameTB.Text;

            NameLB.Text = Name;
        }

        private void option4BTN_Click(object sender, EventArgs e)
        {
            //Declare a string Variable to hold the name.
            String Name;

            //combine the name 
            //result to the name variable
            Name = lastNameTB.Text + ", " + firstNameTB.Text +" "+ middleNameTB.Text
                + ", " + titleCB.Text;

            NameLB.Text = Name;
        }

        private void option5BTN_Click(object sender, EventArgs e)
        {
            //Declare a string Variable to hold the name.
            String Name;

            //combine the name 
            //result to the name variable
            Name = lastNameTB.Text + ", " + firstNameTB.Text + " " + middleNameTB.Text;

            NameLB.Text = Name;
        }

        private void option6BTN_Click(object sender, EventArgs e)
        {
            //Declare a string Variable to hold the name.
            String Name;

            //combine the name 
            //result to the name variable
            Name = lastNameTB.Text + ", " + firstNameTB.Text;

            NameLB.Text = Name;
        }

        private void exitBTN_Click(object sender, EventArgs e)
        {
            //close the form
            this.Close();
        }

        private void clearBTN_Click(object sender, EventArgs e)
        {
            // clear the Text Box Control

            firstNameTB.Text = "";
            middleNameTB.Text = "";
            lastNameTB.Text = "";
            titleCB.Text = "";
            NameLB.Text = "";

            firstNameLB.Focus();
        }
    }
}
