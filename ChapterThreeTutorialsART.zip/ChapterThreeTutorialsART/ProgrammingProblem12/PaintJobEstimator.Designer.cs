﻿namespace ProgrammingProblem12
{
    partial class PaintJobEstimator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelWallSpaceLB = new System.Windows.Forms.Label();
            this.labelPaintCostLB = new System.Windows.Forms.Label();
            this.labelPaintNeededLB = new System.Windows.Forms.Label();
            this.labelLaborRequiredLB = new System.Windows.Forms.Label();
            this.labelLaborCostLB = new System.Windows.Forms.Label();
            this.labelTotalCostLB = new System.Windows.Forms.Label();
            this.outPaintRequiredLB = new System.Windows.Forms.Label();
            this.outLaborHoursLB = new System.Windows.Forms.Label();
            this.outLaborCostLB = new System.Windows.Forms.Label();
            this.outTotalCostLB = new System.Windows.Forms.Label();
            this.inWallSpaceTB = new System.Windows.Forms.TextBox();
            this.inPaintCostTB = new System.Windows.Forms.TextBox();
            this.exitBTN = new System.Windows.Forms.Button();
            this.clearBTN = new System.Windows.Forms.Button();
            this.calculateBTN = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelWallSpaceLB
            // 
            this.labelWallSpaceLB.AutoSize = true;
            this.labelWallSpaceLB.Location = new System.Drawing.Point(9, 20);
            this.labelWallSpaceLB.Name = "labelWallSpaceLB";
            this.labelWallSpaceLB.Size = new System.Drawing.Size(165, 13);
            this.labelWallSpaceLB.TabIndex = 6;
            this.labelWallSpaceLB.Text = "Enter Wall Space in Square Feet:";
            this.labelWallSpaceLB.Click += new System.EventHandler(this.label1_Click);
            // 
            // labelPaintCostLB
            // 
            this.labelPaintCostLB.AutoSize = true;
            this.labelPaintCostLB.Location = new System.Drawing.Point(9, 47);
            this.labelPaintCostLB.Name = "labelPaintCostLB";
            this.labelPaintCostLB.Size = new System.Drawing.Size(137, 13);
            this.labelPaintCostLB.TabIndex = 7;
            this.labelPaintCostLB.Text = "Enter Paint Cost per Gallon:";
            // 
            // labelPaintNeededLB
            // 
            this.labelPaintNeededLB.AutoSize = true;
            this.labelPaintNeededLB.Location = new System.Drawing.Point(9, 74);
            this.labelPaintNeededLB.Name = "labelPaintNeededLB";
            this.labelPaintNeededLB.Size = new System.Drawing.Size(126, 13);
            this.labelPaintNeededLB.TabIndex = 8;
            this.labelPaintNeededLB.Text = "Amount of Paint Needed:\r\n";
            // 
            // labelLaborRequiredLB
            // 
            this.labelLaborRequiredLB.AutoSize = true;
            this.labelLaborRequiredLB.Location = new System.Drawing.Point(9, 101);
            this.labelLaborRequiredLB.Name = "labelLaborRequiredLB";
            this.labelLaborRequiredLB.Size = new System.Drawing.Size(83, 13);
            this.labelLaborRequiredLB.TabIndex = 9;
            this.labelLaborRequiredLB.Text = "Labor Required:";
            // 
            // labelLaborCostLB
            // 
            this.labelLaborCostLB.AutoSize = true;
            this.labelLaborCostLB.Location = new System.Drawing.Point(9, 128);
            this.labelLaborCostLB.Name = "labelLaborCostLB";
            this.labelLaborCostLB.Size = new System.Drawing.Size(61, 13);
            this.labelLaborCostLB.TabIndex = 10;
            this.labelLaborCostLB.Text = "Labor Cost:";
            // 
            // labelTotalCostLB
            // 
            this.labelTotalCostLB.AutoSize = true;
            this.labelTotalCostLB.Location = new System.Drawing.Point(9, 155);
            this.labelTotalCostLB.Name = "labelTotalCostLB";
            this.labelTotalCostLB.Size = new System.Drawing.Size(142, 13);
            this.labelTotalCostLB.TabIndex = 5;
            this.labelTotalCostLB.Text = "Cost for Labor and Materials:";
            // 
            // outPaintRequiredLB
            // 
            this.outPaintRequiredLB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outPaintRequiredLB.Location = new System.Drawing.Point(197, 67);
            this.outPaintRequiredLB.Name = "outPaintRequiredLB";
            this.outPaintRequiredLB.Size = new System.Drawing.Size(100, 23);
            this.outPaintRequiredLB.TabIndex = 14;
            this.outPaintRequiredLB.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // outLaborHoursLB
            // 
            this.outLaborHoursLB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outLaborHoursLB.Location = new System.Drawing.Point(197, 95);
            this.outLaborHoursLB.Name = "outLaborHoursLB";
            this.outLaborHoursLB.Size = new System.Drawing.Size(100, 23);
            this.outLaborHoursLB.TabIndex = 13;
            this.outLaborHoursLB.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // outLaborCostLB
            // 
            this.outLaborCostLB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outLaborCostLB.Location = new System.Drawing.Point(197, 123);
            this.outLaborCostLB.Name = "outLaborCostLB";
            this.outLaborCostLB.Size = new System.Drawing.Size(100, 23);
            this.outLaborCostLB.TabIndex = 12;
            this.outLaborCostLB.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // outTotalCostLB
            // 
            this.outTotalCostLB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outTotalCostLB.Location = new System.Drawing.Point(197, 151);
            this.outTotalCostLB.Name = "outTotalCostLB";
            this.outTotalCostLB.Size = new System.Drawing.Size(100, 23);
            this.outTotalCostLB.TabIndex = 11;
            this.outTotalCostLB.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // inWallSpaceTB
            // 
            this.inWallSpaceTB.BackColor = System.Drawing.Color.Chartreuse;
            this.inWallSpaceTB.ForeColor = System.Drawing.SystemColors.WindowText;
            this.inWallSpaceTB.Location = new System.Drawing.Point(197, 17);
            this.inWallSpaceTB.Name = "inWallSpaceTB";
            this.inWallSpaceTB.Size = new System.Drawing.Size(100, 20);
            this.inWallSpaceTB.TabIndex = 0;
            this.inWallSpaceTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.inWallSpaceTB.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // inPaintCostTB
            // 
            this.inPaintCostTB.BackColor = System.Drawing.Color.Chartreuse;
            this.inPaintCostTB.Location = new System.Drawing.Point(197, 42);
            this.inPaintCostTB.Name = "inPaintCostTB";
            this.inPaintCostTB.Size = new System.Drawing.Size(100, 20);
            this.inPaintCostTB.TabIndex = 1;
            this.inPaintCostTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // exitBTN
            // 
            this.exitBTN.Location = new System.Drawing.Point(151, 226);
            this.exitBTN.Name = "exitBTN";
            this.exitBTN.Size = new System.Drawing.Size(121, 23);
            this.exitBTN.TabIndex = 4;
            this.exitBTN.Text = "EXIT";
            this.exitBTN.UseVisualStyleBackColor = true;
            this.exitBTN.Click += new System.EventHandler(this.button1_Click);
            // 
            // clearBTN
            // 
            this.clearBTN.Location = new System.Drawing.Point(12, 226);
            this.clearBTN.Name = "clearBTN";
            this.clearBTN.Size = new System.Drawing.Size(121, 23);
            this.clearBTN.TabIndex = 3;
            this.clearBTN.Text = "CLEAR";
            this.clearBTN.UseVisualStyleBackColor = true;
            this.clearBTN.Click += new System.EventHandler(this.button2_Click);
            // 
            // calculateBTN
            // 
            this.calculateBTN.Location = new System.Drawing.Point(12, 194);
            this.calculateBTN.Name = "calculateBTN";
            this.calculateBTN.Size = new System.Drawing.Size(121, 23);
            this.calculateBTN.TabIndex = 2;
            this.calculateBTN.Text = "CALCULATE";
            this.calculateBTN.UseVisualStyleBackColor = true;
            this.calculateBTN.Click += new System.EventHandler(this.button3_Click);
            // 
            // PaintJobEstimator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(323, 261);
            this.Controls.Add(this.calculateBTN);
            this.Controls.Add(this.clearBTN);
            this.Controls.Add(this.exitBTN);
            this.Controls.Add(this.inPaintCostTB);
            this.Controls.Add(this.inWallSpaceTB);
            this.Controls.Add(this.outTotalCostLB);
            this.Controls.Add(this.outLaborCostLB);
            this.Controls.Add(this.outLaborHoursLB);
            this.Controls.Add(this.outPaintRequiredLB);
            this.Controls.Add(this.labelTotalCostLB);
            this.Controls.Add(this.labelLaborCostLB);
            this.Controls.Add(this.labelLaborRequiredLB);
            this.Controls.Add(this.labelPaintNeededLB);
            this.Controls.Add(this.labelPaintCostLB);
            this.Controls.Add(this.labelWallSpaceLB);
            this.Name = "PaintJobEstimator";
            this.Text = "Paint Job Estimator";
            this.Load += new System.EventHandler(this.PaintJobEstimator_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelWallSpaceLB;
        private System.Windows.Forms.Label labelPaintCostLB;
        private System.Windows.Forms.Label labelPaintNeededLB;
        private System.Windows.Forms.Label labelLaborRequiredLB;
        private System.Windows.Forms.Label labelLaborCostLB;
        private System.Windows.Forms.Label labelTotalCostLB;
        private System.Windows.Forms.Label outPaintRequiredLB;
        private System.Windows.Forms.Label outLaborHoursLB;
        private System.Windows.Forms.Label outLaborCostLB;
        private System.Windows.Forms.Label outTotalCostLB;
        private System.Windows.Forms.TextBox inWallSpaceTB;
        private System.Windows.Forms.TextBox inPaintCostTB;
        private System.Windows.Forms.Button exitBTN;
        private System.Windows.Forms.Button clearBTN;
        private System.Windows.Forms.Button calculateBTN;
    }
}

