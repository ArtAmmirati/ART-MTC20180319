﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProgrammingProblem12
{
    public partial class PaintJobEstimator : Form
    {
        public PaintJobEstimator()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        
        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                //declare variables
                decimal wallspace;
                decimal paintcost;
                decimal gallons;
                decimal hours;
                decimal labor;
                decimal total;

                // calculations

                wallspace = decimal.Parse(inWallSpaceTB.Text);
                paintcost = decimal.Parse(inPaintCostTB.Text);
                hours = decimal.Parse("14.375");
                hours = wallspace / hours;
                labor = decimal.Parse("20");
                labor = hours * labor;
                gallons = decimal.Parse("115");
                gallons = wallspace / 115;
                gallons = Math.Ceiling(gallons);
                paintcost = paintcost * 1;
                total = (paintcost * gallons) + labor;

                //Display results
                outPaintRequiredLB.Text = gallons.ToString() + "  " + "Gallons";
                outLaborHoursLB.Text = hours.ToString("n2") + "  " + "Hours";
                outLaborCostLB.Text = labor.ToString("c");
                outTotalCostLB.Text = total.ToString("c");
                inWallSpaceTB.Text = wallspace.ToString() + "   " + "SqFt.";
                inPaintCostTB.Text = paintcost.ToString("c");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            inWallSpaceTB.Text = "";
            inPaintCostTB.Text = "";
            outPaintRequiredLB.Text = "";
            outLaborHoursLB.Text = "";
            outLaborCostLB.Text = "";
            outTotalCostLB.Text = "";

            inWallSpaceTB.Focus();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //close form
            this.Close();
        }

        private void PaintJobEstimator_Load(object sender, EventArgs e)
        {

        }
    }
}
