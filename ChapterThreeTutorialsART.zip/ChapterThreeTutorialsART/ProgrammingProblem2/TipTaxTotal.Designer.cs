﻿namespace ProgrammingProblem2
{
    partial class TipTaxTotal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.calculateBTN = new System.Windows.Forms.Button();
            this.foodChargeTB = new System.Windows.Forms.TextBox();
            this.foodChargeLB = new System.Windows.Forms.Label();
            this.salesTaxLB = new System.Windows.Forms.Label();
            this.saleTaxAmountLB = new System.Windows.Forms.Label();
            this.tipLB = new System.Windows.Forms.Label();
            this.tipAmountLB = new System.Windows.Forms.Label();
            this.totalLB = new System.Windows.Forms.Label();
            this.outputTotalLB = new System.Windows.Forms.Label();
            this.clearBTN = new System.Windows.Forms.Button();
            this.exitBTN = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // calculateBTN
            // 
            this.calculateBTN.Location = new System.Drawing.Point(15, 217);
            this.calculateBTN.Name = "calculateBTN";
            this.calculateBTN.Size = new System.Drawing.Size(75, 23);
            this.calculateBTN.TabIndex = 1;
            this.calculateBTN.Text = "Calculate";
            this.calculateBTN.UseVisualStyleBackColor = true;
            this.calculateBTN.Click += new System.EventHandler(this.calculateBTN_Click);
            // 
            // foodChargeTB
            // 
            this.foodChargeTB.BackColor = System.Drawing.Color.Lime;
            this.foodChargeTB.Location = new System.Drawing.Point(153, 12);
            this.foodChargeTB.Name = "foodChargeTB";
            this.foodChargeTB.Size = new System.Drawing.Size(119, 20);
            this.foodChargeTB.TabIndex = 0;
            this.foodChargeTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // foodChargeLB
            // 
            this.foodChargeLB.AutoSize = true;
            this.foodChargeLB.Location = new System.Drawing.Point(12, 15);
            this.foodChargeLB.Name = "foodChargeLB";
            this.foodChargeLB.Size = new System.Drawing.Size(114, 13);
            this.foodChargeLB.TabIndex = 4;
            this.foodChargeLB.Text = "Enter the Food Charge";
            // 
            // salesTaxLB
            // 
            this.salesTaxLB.AutoSize = true;
            this.salesTaxLB.Location = new System.Drawing.Point(15, 50);
            this.salesTaxLB.Name = "salesTaxLB";
            this.salesTaxLB.Size = new System.Drawing.Size(54, 13);
            this.salesTaxLB.TabIndex = 5;
            this.salesTaxLB.Text = "Sales Tax";
            // 
            // saleTaxAmountLB
            // 
            this.saleTaxAmountLB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.saleTaxAmountLB.Location = new System.Drawing.Point(153, 49);
            this.saleTaxAmountLB.Name = "saleTaxAmountLB";
            this.saleTaxAmountLB.Size = new System.Drawing.Size(119, 22);
            this.saleTaxAmountLB.TabIndex = 10;
            this.saleTaxAmountLB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tipLB
            // 
            this.tipLB.AutoSize = true;
            this.tipLB.Location = new System.Drawing.Point(12, 91);
            this.tipLB.Name = "tipLB";
            this.tipLB.Size = new System.Drawing.Size(61, 13);
            this.tipLB.TabIndex = 6;
            this.tipLB.Text = "Tip Amount";
            this.tipLB.Click += new System.EventHandler(this.tipAmountLB_Click);
            // 
            // tipAmountLB
            // 
            this.tipAmountLB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tipAmountLB.Location = new System.Drawing.Point(153, 90);
            this.tipAmountLB.Name = "tipAmountLB";
            this.tipAmountLB.Size = new System.Drawing.Size(119, 23);
            this.tipAmountLB.TabIndex = 9;
            this.tipAmountLB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // totalLB
            // 
            this.totalLB.AutoSize = true;
            this.totalLB.Location = new System.Drawing.Point(18, 133);
            this.totalLB.Name = "totalLB";
            this.totalLB.Size = new System.Drawing.Size(31, 13);
            this.totalLB.TabIndex = 7;
            this.totalLB.Text = "Total";
            this.totalLB.Click += new System.EventHandler(this.totalLB_Click);
            // 
            // outputTotalLB
            // 
            this.outputTotalLB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputTotalLB.Location = new System.Drawing.Point(153, 128);
            this.outputTotalLB.Name = "outputTotalLB";
            this.outputTotalLB.Size = new System.Drawing.Size(119, 23);
            this.outputTotalLB.TabIndex = 8;
            this.outputTotalLB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.outputTotalLB.Click += new System.EventHandler(this.label2_Click);
            // 
            // clearBTN
            // 
            this.clearBTN.Location = new System.Drawing.Point(105, 217);
            this.clearBTN.Name = "clearBTN";
            this.clearBTN.Size = new System.Drawing.Size(75, 23);
            this.clearBTN.TabIndex = 2;
            this.clearBTN.Text = "Clear";
            this.clearBTN.UseVisualStyleBackColor = true;
            this.clearBTN.Click += new System.EventHandler(this.clearBTN_Click);
            // 
            // exitBTN
            // 
            this.exitBTN.Location = new System.Drawing.Point(197, 217);
            this.exitBTN.Name = "exitBTN";
            this.exitBTN.Size = new System.Drawing.Size(75, 23);
            this.exitBTN.TabIndex = 3;
            this.exitBTN.Text = "Exit";
            this.exitBTN.UseVisualStyleBackColor = true;
            this.exitBTN.Click += new System.EventHandler(this.exitBTN_Click);
            // 
            // TipTaxTotal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.exitBTN);
            this.Controls.Add(this.clearBTN);
            this.Controls.Add(this.outputTotalLB);
            this.Controls.Add(this.totalLB);
            this.Controls.Add(this.tipAmountLB);
            this.Controls.Add(this.tipLB);
            this.Controls.Add(this.saleTaxAmountLB);
            this.Controls.Add(this.salesTaxLB);
            this.Controls.Add(this.foodChargeLB);
            this.Controls.Add(this.foodChargeTB);
            this.Controls.Add(this.calculateBTN);
            this.Name = "TipTaxTotal";
            this.Text = "1";
            this.Load += new System.EventHandler(this.TipTaxTotal_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button calculateBTN;
        private System.Windows.Forms.TextBox foodChargeTB;
        private System.Windows.Forms.Label foodChargeLB;
        private System.Windows.Forms.Label salesTaxLB;
        private System.Windows.Forms.Label saleTaxAmountLB;
        private System.Windows.Forms.Label tipLB;
        private System.Windows.Forms.Label tipAmountLB;
        private System.Windows.Forms.Label totalLB;
        private System.Windows.Forms.Label outputTotalLB;
        private System.Windows.Forms.Button clearBTN;
        private System.Windows.Forms.Button exitBTN;
    }
}

