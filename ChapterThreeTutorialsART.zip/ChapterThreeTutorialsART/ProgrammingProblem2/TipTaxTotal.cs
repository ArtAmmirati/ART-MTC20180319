﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProgrammingProblem2
{
    public partial class TipTaxTotal : Form
    {
        const decimal SALES_TAX_RATE_VALUE = 0.07M;
        const decimal TIP_RATE = 0.15m;

        //Field variable to hold the total
        //initiated with 0.
        private decimal total = 0m;

        public TipTaxTotal()
        {
            InitializeComponent();
        }

        private void TipTaxTotal_Load(object sender, EventArgs e)
        {

        }

        private void tipAmountLB_Click(object sender, EventArgs e)
        {

        }

        private void totalLB_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void calculateBTN_Click(object sender, EventArgs e)
        {
            try
            {
                // declare variables

                decimal foodCharge;//holds the food charges
                decimal salesTax;
                decimal tip;
                decimal total;

                // Get food charges
                foodCharge = decimal.Parse(foodChargeTB.Text);

                //Calculate amounts
                salesTax = foodCharge * SALES_TAX_RATE_VALUE;
                tip = (foodCharge + salesTax) * TIP_RATE;
                total = foodCharge + salesTax + tip;

                // display the amounts
                foodChargeTB.Text = foodCharge.ToString("c");
                saleTaxAmountLB.Text = salesTax.ToString("c");
                tipAmountLB.Text = tip.ToString("c");
                outputTotalLB.Text = total.ToString("c");
            }
            catch (Exception ex)
            {
                // display error message
                MessageBox.Show(ex.Message);
            }

        }

        private void clearBTN_Click(object sender, EventArgs e)
        {
            //Clear the textbox controls.

            foodChargeTB.Text = "";
            saleTaxAmountLB.Text = "";
            tipAmountLB.Text = "";
            outputTotalLB.Text = "";

            foodChargeLB.Focus();
        }

        private void exitBTN_Click(object sender, EventArgs e)
        {
            //Close the form
            this.Close();
        }
    }
}
