﻿namespace ProgrammingProblem3
{
    partial class DIstanceTraveled5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CalculateBTN = new System.Windows.Forms.Button();
            this.ClearBTN = new System.Windows.Forms.Button();
            this.ExitBTN = new System.Windows.Forms.Button();
            this.speedInputLB = new System.Windows.Forms.Label();
            this.distanceTraveledFive = new System.Windows.Forms.Label();
            this.distanceTraveled8 = new System.Windows.Forms.Label();
            this.distanceTraveled12 = new System.Windows.Forms.Label();
            this.speedInputTB = new System.Windows.Forms.TextBox();
            this.outputAfter5LB = new System.Windows.Forms.Label();
            this.outputAfter8LB = new System.Windows.Forms.Label();
            this.outputAfter12LB = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // CalculateBTN
            // 
            this.CalculateBTN.Location = new System.Drawing.Point(13, 226);
            this.CalculateBTN.Name = "CalculateBTN";
            this.CalculateBTN.Size = new System.Drawing.Size(95, 23);
            this.CalculateBTN.TabIndex = 4;
            this.CalculateBTN.Text = "Calculate";
            this.CalculateBTN.UseVisualStyleBackColor = true;
            this.CalculateBTN.Click += new System.EventHandler(this.CalculateBTN_Click);
            // 
            // ClearBTN
            // 
            this.ClearBTN.Location = new System.Drawing.Point(126, 226);
            this.ClearBTN.Name = "ClearBTN";
            this.ClearBTN.Size = new System.Drawing.Size(95, 23);
            this.ClearBTN.TabIndex = 5;
            this.ClearBTN.Text = "Clear";
            this.ClearBTN.UseVisualStyleBackColor = true;
            this.ClearBTN.Click += new System.EventHandler(this.ClearBTN_Click);
            // 
            // ExitBTN
            // 
            this.ExitBTN.Location = new System.Drawing.Point(240, 226);
            this.ExitBTN.Name = "ExitBTN";
            this.ExitBTN.Size = new System.Drawing.Size(95, 23);
            this.ExitBTN.TabIndex = 6;
            this.ExitBTN.Text = "Exit";
            this.ExitBTN.UseVisualStyleBackColor = true;
            this.ExitBTN.Click += new System.EventHandler(this.button3_Click);
            // 
            // speedInputLB
            // 
            this.speedInputLB.AutoSize = true;
            this.speedInputLB.Location = new System.Drawing.Point(22, 9);
            this.speedInputLB.Name = "speedInputLB";
            this.speedInputLB.Size = new System.Drawing.Size(108, 13);
            this.speedInputLB.TabIndex = 7;
            this.speedInputLB.Text = "Enter the cars speed:";
            // 
            // distanceTraveledFive
            // 
            this.distanceTraveledFive.AutoSize = true;
            this.distanceTraveledFive.Location = new System.Drawing.Point(22, 56);
            this.distanceTraveledFive.Name = "distanceTraveledFive";
            this.distanceTraveledFive.Size = new System.Drawing.Size(155, 13);
            this.distanceTraveledFive.TabIndex = 8;
            this.distanceTraveledFive.Text = "Distance traveled after 5 hours:";
            this.distanceTraveledFive.Click += new System.EventHandler(this.label2_Click);
            // 
            // distanceTraveled8
            // 
            this.distanceTraveled8.AutoSize = true;
            this.distanceTraveled8.Location = new System.Drawing.Point(22, 103);
            this.distanceTraveled8.Name = "distanceTraveled8";
            this.distanceTraveled8.Size = new System.Drawing.Size(155, 13);
            this.distanceTraveled8.TabIndex = 9;
            this.distanceTraveled8.Text = "Distance traveled after 8 hours:";
            this.distanceTraveled8.Click += new System.EventHandler(this.distanceTraveled8_Click);
            // 
            // distanceTraveled12
            // 
            this.distanceTraveled12.AutoSize = true;
            this.distanceTraveled12.Location = new System.Drawing.Point(22, 150);
            this.distanceTraveled12.Name = "distanceTraveled12";
            this.distanceTraveled12.Size = new System.Drawing.Size(161, 13);
            this.distanceTraveled12.TabIndex = 10;
            this.distanceTraveled12.Text = "Distance traveled after 12 hours:";
            // 
            // speedInputTB
            // 
            this.speedInputTB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.speedInputTB.Location = new System.Drawing.Point(206, 6);
            this.speedInputTB.Name = "speedInputTB";
            this.speedInputTB.Size = new System.Drawing.Size(129, 20);
            this.speedInputTB.TabIndex = 0;
            this.speedInputTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.speedInputTB.TextChanged += new System.EventHandler(this.speedInputTB_TextChanged);
            // 
            // outputAfter5LB
            // 
            this.outputAfter5LB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputAfter5LB.Location = new System.Drawing.Point(206, 51);
            this.outputAfter5LB.Name = "outputAfter5LB";
            this.outputAfter5LB.Size = new System.Drawing.Size(129, 23);
            this.outputAfter5LB.TabIndex = 1;
            this.outputAfter5LB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // outputAfter8LB
            // 
            this.outputAfter8LB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputAfter8LB.Location = new System.Drawing.Point(206, 98);
            this.outputAfter8LB.Name = "outputAfter8LB";
            this.outputAfter8LB.Size = new System.Drawing.Size(129, 23);
            this.outputAfter8LB.TabIndex = 2;
            this.outputAfter8LB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.outputAfter8LB.Click += new System.EventHandler(this.outputAfter8_Click);
            // 
            // outputAfter12LB
            // 
            this.outputAfter12LB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputAfter12LB.Location = new System.Drawing.Point(206, 145);
            this.outputAfter12LB.Name = "outputAfter12LB";
            this.outputAfter12LB.Size = new System.Drawing.Size(129, 23);
            this.outputAfter12LB.TabIndex = 3;
            this.outputAfter12LB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DIstanceTraveled5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(359, 261);
            this.Controls.Add(this.outputAfter12LB);
            this.Controls.Add(this.outputAfter8LB);
            this.Controls.Add(this.outputAfter5LB);
            this.Controls.Add(this.speedInputTB);
            this.Controls.Add(this.distanceTraveled12);
            this.Controls.Add(this.distanceTraveled8);
            this.Controls.Add(this.distanceTraveledFive);
            this.Controls.Add(this.speedInputLB);
            this.Controls.Add(this.ExitBTN);
            this.Controls.Add(this.ClearBTN);
            this.Controls.Add(this.CalculateBTN);
            this.Name = "DIstanceTraveled5";
            this.Text = "DIstance Traveled";
            this.Load += new System.EventHandler(this.DIstanceTraveled5_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button CalculateBTN;
        private System.Windows.Forms.Button ClearBTN;
        private System.Windows.Forms.Button ExitBTN;
        private System.Windows.Forms.Label speedInputLB;
        private System.Windows.Forms.Label distanceTraveledFive;
        private System.Windows.Forms.Label distanceTraveled8;
        private System.Windows.Forms.Label distanceTraveled12;
        private System.Windows.Forms.TextBox speedInputTB;
        private System.Windows.Forms.Label outputAfter5LB;
        private System.Windows.Forms.Label outputAfter8LB;
        private System.Windows.Forms.Label outputAfter12LB;
    }
}

