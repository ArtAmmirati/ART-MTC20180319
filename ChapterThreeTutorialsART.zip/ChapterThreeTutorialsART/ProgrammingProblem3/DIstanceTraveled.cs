﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProgrammingProblem3
{
    public partial class DIstanceTraveled5 : Form
    {
        public DIstanceTraveled5()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void distanceTraveled8_Click(object sender, EventArgs e)
        {

        }

        private void outputAfter8_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            // close form
            this.Close();
        }

        private void CalculateBTN_Click(object sender, EventArgs e)
        {
            try
            {
                // declare variables
                double fivehours;
                double eighthours;
                double twelvehours;
                double speed;

                //get mile per hour
                speed = double.Parse(speedInputTB.Text);
                fivehours = speed * 5;
                eighthours = speed * 8;
                twelvehours = speed * 12;
                //Display values
                outputAfter5LB.Text = fivehours.ToString() + " " + "Miles";
                outputAfter8LB.Text = eighthours.ToString() + " " + "Miles";
                outputAfter12LB.Text = twelvehours.ToString() + " " + "Miles";
                speedInputTB.Text = speed.ToString() + " " + "MPH";
            }
            catch (Exception ex)
            {
                // display message
                MessageBox.Show(ex.Message);
            }

        }

        private void speedInputTB_TextChanged(object sender, EventArgs e)
        {

        }

        private void ClearBTN_Click(object sender, EventArgs e)
        {
            // clear the boxes
            speedInputTB.Text = "";
            outputAfter5LB.Text = "";
            outputAfter8LB.Text = "";
            outputAfter12LB.Text = "";

            speedInputLB.Focus();
        }

        private void DIstanceTraveled5_Load(object sender, EventArgs e)
        {

        }
    }
}
