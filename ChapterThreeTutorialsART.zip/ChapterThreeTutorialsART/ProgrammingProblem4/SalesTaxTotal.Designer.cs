﻿namespace ProgrammingProblem4
{
    partial class SalesTaxTotal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.purchaseAmtLB = new System.Windows.Forms.Label();
            this.stateTaxLB = new System.Windows.Forms.Label();
            this.countyTaxLB = new System.Windows.Forms.Label();
            this.totalLb = new System.Windows.Forms.Label();
            this.outputTotalLB = new System.Windows.Forms.Label();
            this.outputCountyTaxLB = new System.Windows.Forms.Label();
            this.outputStateTaxLB = new System.Windows.Forms.Label();
            this.inputPurchaseAmtTB = new System.Windows.Forms.TextBox();
            this.calculateBTN = new System.Windows.Forms.Button();
            this.clearBTN = new System.Windows.Forms.Button();
            this.exitBTN = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // purchaseAmtLB
            // 
            this.purchaseAmtLB.AutoSize = true;
            this.purchaseAmtLB.Location = new System.Drawing.Point(16, 28);
            this.purchaseAmtLB.Name = "purchaseAmtLB";
            this.purchaseAmtLB.Size = new System.Drawing.Size(138, 13);
            this.purchaseAmtLB.TabIndex = 0;
            this.purchaseAmtLB.Text = "Enter the purchase amount:";
            this.purchaseAmtLB.Click += new System.EventHandler(this.label1_Click);
            // 
            // stateTaxLB
            // 
            this.stateTaxLB.AutoSize = true;
            this.stateTaxLB.Location = new System.Drawing.Point(16, 63);
            this.stateTaxLB.Name = "stateTaxLB";
            this.stateTaxLB.Size = new System.Drawing.Size(56, 13);
            this.stateTaxLB.TabIndex = 1;
            this.stateTaxLB.Text = "State Tax:";
            this.stateTaxLB.Click += new System.EventHandler(this.label2_Click);
            // 
            // countyTaxLB
            // 
            this.countyTaxLB.AutoSize = true;
            this.countyTaxLB.Location = new System.Drawing.Point(16, 98);
            this.countyTaxLB.Name = "countyTaxLB";
            this.countyTaxLB.Size = new System.Drawing.Size(64, 13);
            this.countyTaxLB.TabIndex = 2;
            this.countyTaxLB.Text = "County Tax:";
            // 
            // totalLb
            // 
            this.totalLb.AutoSize = true;
            this.totalLb.Location = new System.Drawing.Point(16, 133);
            this.totalLb.Name = "totalLb";
            this.totalLb.Size = new System.Drawing.Size(34, 13);
            this.totalLb.TabIndex = 3;
            this.totalLb.Text = "Total:";
            // 
            // outputTotalLB
            // 
            this.outputTotalLB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputTotalLB.Location = new System.Drawing.Point(172, 132);
            this.outputTotalLB.Name = "outputTotalLB";
            this.outputTotalLB.Size = new System.Drawing.Size(100, 23);
            this.outputTotalLB.TabIndex = 3;
            this.outputTotalLB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.outputTotalLB.Click += new System.EventHandler(this.label5_Click);
            // 
            // outputCountyTaxLB
            // 
            this.outputCountyTaxLB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputCountyTaxLB.Location = new System.Drawing.Point(172, 97);
            this.outputCountyTaxLB.Name = "outputCountyTaxLB";
            this.outputCountyTaxLB.Size = new System.Drawing.Size(100, 23);
            this.outputCountyTaxLB.TabIndex = 2;
            this.outputCountyTaxLB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.outputCountyTaxLB.Click += new System.EventHandler(this.outputCountyTaxLB_Click);
            // 
            // outputStateTaxLB
            // 
            this.outputStateTaxLB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputStateTaxLB.Location = new System.Drawing.Point(172, 62);
            this.outputStateTaxLB.Name = "outputStateTaxLB";
            this.outputStateTaxLB.Size = new System.Drawing.Size(100, 23);
            this.outputStateTaxLB.TabIndex = 1;
            this.outputStateTaxLB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // inputPurchaseAmtTB
            // 
            this.inputPurchaseAmtTB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.inputPurchaseAmtTB.Location = new System.Drawing.Point(172, 25);
            this.inputPurchaseAmtTB.Name = "inputPurchaseAmtTB";
            this.inputPurchaseAmtTB.Size = new System.Drawing.Size(100, 20);
            this.inputPurchaseAmtTB.TabIndex = 0;
            this.inputPurchaseAmtTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.inputPurchaseAmtTB.TextChanged += new System.EventHandler(this.inputPurchaseAmtTB_TextChanged);
            // 
            // calculateBTN
            // 
            this.calculateBTN.Location = new System.Drawing.Point(19, 189);
            this.calculateBTN.Name = "calculateBTN";
            this.calculateBTN.Size = new System.Drawing.Size(75, 23);
            this.calculateBTN.TabIndex = 4;
            this.calculateBTN.Text = "Calculate";
            this.calculateBTN.UseVisualStyleBackColor = true;
            this.calculateBTN.Click += new System.EventHandler(this.calculateBTN_Click);
            // 
            // clearBTN
            // 
            this.clearBTN.Location = new System.Drawing.Point(100, 189);
            this.clearBTN.Name = "clearBTN";
            this.clearBTN.Size = new System.Drawing.Size(75, 23);
            this.clearBTN.TabIndex = 5;
            this.clearBTN.Text = "Clear";
            this.clearBTN.UseVisualStyleBackColor = true;
            this.clearBTN.Click += new System.EventHandler(this.clearBTN_Click);
            // 
            // exitBTN
            // 
            this.exitBTN.Location = new System.Drawing.Point(181, 189);
            this.exitBTN.Name = "exitBTN";
            this.exitBTN.Size = new System.Drawing.Size(75, 23);
            this.exitBTN.TabIndex = 6;
            this.exitBTN.Text = "Exit";
            this.exitBTN.UseVisualStyleBackColor = true;
            this.exitBTN.Click += new System.EventHandler(this.exitBTN_Click);
            // 
            // SalesTaxTotal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 236);
            this.Controls.Add(this.exitBTN);
            this.Controls.Add(this.clearBTN);
            this.Controls.Add(this.calculateBTN);
            this.Controls.Add(this.inputPurchaseAmtTB);
            this.Controls.Add(this.outputStateTaxLB);
            this.Controls.Add(this.outputCountyTaxLB);
            this.Controls.Add(this.outputTotalLB);
            this.Controls.Add(this.totalLb);
            this.Controls.Add(this.countyTaxLB);
            this.Controls.Add(this.stateTaxLB);
            this.Controls.Add(this.purchaseAmtLB);
            this.Name = "SalesTaxTotal";
            this.Text = "Sales Tax and Total";
            this.Load += new System.EventHandler(this.SalesTaxTotal_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label purchaseAmtLB;
        private System.Windows.Forms.Label stateTaxLB;
        private System.Windows.Forms.Label countyTaxLB;
        private System.Windows.Forms.Label totalLb;
        private System.Windows.Forms.Label outputTotalLB;
        private System.Windows.Forms.Label outputCountyTaxLB;
        private System.Windows.Forms.Label outputStateTaxLB;
        private System.Windows.Forms.TextBox inputPurchaseAmtTB;
        private System.Windows.Forms.Button calculateBTN;
        private System.Windows.Forms.Button clearBTN;
        private System.Windows.Forms.Button exitBTN;
    }
}

