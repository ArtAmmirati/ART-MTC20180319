﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProgrammingProblem4
{
    public partial class SalesTaxTotal : Form


    {
        //Constant fields
        const decimal STATE_SALES_TAX = .04m;
        const decimal COUNTY_SALES_TAX = .02m;
        // initialized field variable  with 0
        private decimal total = 0m;

        public SalesTaxTotal()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void SalesTaxTotal_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void inputPurchaseAmtTB_TextChanged(object sender, EventArgs e)
        {

        }

        private void exitBTN_Click(object sender, EventArgs e)
        {
            //Close the form
            this.Close();
        }

        private void calculateBTN_Click(object sender, EventArgs e)
        {
            try
            { 
                // declare variables
                decimal PurchaseAmt; // input purchase amount
                decimal StateTax;      // output of state tax
                decimal CountyTax;     // output of county tax
                decimal Total;         // output of total

                // get the purchase amount
                PurchaseAmt = decimal.Parse(inputPurchaseAmtTB.Text);

                //get state tax
                StateTax = PurchaseAmt * STATE_SALES_TAX;
               
                // get county tax
              
                CountyTax = PurchaseAmt * COUNTY_SALES_TAX;

                // total
                Total = PurchaseAmt + StateTax + CountyTax;

                //display
                inputPurchaseAmtTB.Text = PurchaseAmt.ToString("c");
                outputStateTaxLB.Text = StateTax.ToString("c");
                outputCountyTaxLB.Text = CountyTax.ToString("c");
                outputTotalLB.Text = Total.ToString("c");



                

            }
            catch (Exception ex)
           
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void outputCountyTaxLB_Click(object sender, EventArgs e)
        {

        }

        private void clearBTN_Click(object sender, EventArgs e)
        {
            // clear tb lb controls
            inputPurchaseAmtTB.Text = "";
            outputStateTaxLB.Text = "";
            outputCountyTaxLB.Text = "";
            outputTotalLB.Text = "";

            //set focus to inputPurchaseAmtTB
            inputPurchaseAmtTB.Focus();
        }
    }
}
