﻿namespace ProgrammingProblem5
{
    partial class CtoFTempConverter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.toFahrenheitBTN = new System.Windows.Forms.Button();
            this.toCelsiusBTN = new System.Windows.Forms.Button();
            this.clearBTN = new System.Windows.Forms.Button();
            this.exitBTN = new System.Windows.Forms.Button();
            this.inputTempTB = new System.Windows.Forms.TextBox();
            this.outputTempLB = new System.Windows.Forms.Label();
            this.enterTempLB = new System.Windows.Forms.Label();
            this.convertedTempLB = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // toFahrenheitBTN
            // 
            this.toFahrenheitBTN.Location = new System.Drawing.Point(38, 148);
            this.toFahrenheitBTN.Name = "toFahrenheitBTN";
            this.toFahrenheitBTN.Size = new System.Drawing.Size(75, 46);
            this.toFahrenheitBTN.TabIndex = 2;
            this.toFahrenheitBTN.Text = "Convert to Farhrenheit";
            this.toFahrenheitBTN.UseVisualStyleBackColor = true;
            this.toFahrenheitBTN.Click += new System.EventHandler(this.toFahrenheitBTN_Click);
            // 
            // toCelsiusBTN
            // 
            this.toCelsiusBTN.Location = new System.Drawing.Point(161, 148);
            this.toCelsiusBTN.Name = "toCelsiusBTN";
            this.toCelsiusBTN.Size = new System.Drawing.Size(75, 46);
            this.toCelsiusBTN.TabIndex = 3;
            this.toCelsiusBTN.Text = "Convert to Celsius";
            this.toCelsiusBTN.UseVisualStyleBackColor = true;
            this.toCelsiusBTN.Click += new System.EventHandler(this.toCelsiusBTN_Click);
            // 
            // clearBTN
            // 
            this.clearBTN.Location = new System.Drawing.Point(38, 214);
            this.clearBTN.Name = "clearBTN";
            this.clearBTN.Size = new System.Drawing.Size(75, 23);
            this.clearBTN.TabIndex = 4;
            this.clearBTN.Text = "Clear";
            this.clearBTN.UseVisualStyleBackColor = true;
            this.clearBTN.Click += new System.EventHandler(this.clearBTN_Click);
            // 
            // exitBTN
            // 
            this.exitBTN.Location = new System.Drawing.Point(161, 214);
            this.exitBTN.Name = "exitBTN";
            this.exitBTN.Size = new System.Drawing.Size(75, 23);
            this.exitBTN.TabIndex = 5;
            this.exitBTN.Text = "Exit";
            this.exitBTN.UseVisualStyleBackColor = true;
            this.exitBTN.Click += new System.EventHandler(this.exitBTN_Click);
            // 
            // inputTempTB
            // 
            this.inputTempTB.Location = new System.Drawing.Point(38, 37);
            this.inputTempTB.Name = "inputTempTB";
            this.inputTempTB.Size = new System.Drawing.Size(198, 20);
            this.inputTempTB.TabIndex = 0;
            this.inputTempTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // outputTempLB
            // 
            this.outputTempLB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputTempLB.Location = new System.Drawing.Point(38, 103);
            this.outputTempLB.Name = "outputTempLB";
            this.outputTempLB.Size = new System.Drawing.Size(198, 27);
            this.outputTempLB.TabIndex = 1;
            this.outputTempLB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // enterTempLB
            // 
            this.enterTempLB.Location = new System.Drawing.Point(38, 13);
            this.enterTempLB.Name = "enterTempLB";
            this.enterTempLB.Size = new System.Drawing.Size(198, 23);
            this.enterTempLB.TabIndex = 6;
            this.enterTempLB.Text = "Input the Temperature to Convert";
            this.enterTempLB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.enterTempLB.Click += new System.EventHandler(this.label1_Click);
            // 
            // convertedTempLB
            // 
            this.convertedTempLB.Location = new System.Drawing.Point(38, 73);
            this.convertedTempLB.Name = "convertedTempLB";
            this.convertedTempLB.Size = new System.Drawing.Size(198, 23);
            this.convertedTempLB.TabIndex = 7;
            this.convertedTempLB.Text = "Converted Temperature";
            this.convertedTempLB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CtoFTempConverter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.convertedTempLB);
            this.Controls.Add(this.enterTempLB);
            this.Controls.Add(this.outputTempLB);
            this.Controls.Add(this.inputTempTB);
            this.Controls.Add(this.exitBTN);
            this.Controls.Add(this.clearBTN);
            this.Controls.Add(this.toCelsiusBTN);
            this.Controls.Add(this.toFahrenheitBTN);
            this.Name = "CtoFTempConverter";
            this.Text = "Temperature Converter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button toFahrenheitBTN;
        private System.Windows.Forms.Button toCelsiusBTN;
        private System.Windows.Forms.Button clearBTN;
        private System.Windows.Forms.Button exitBTN;
        private System.Windows.Forms.TextBox inputTempTB;
        private System.Windows.Forms.Label outputTempLB;
        private System.Windows.Forms.Label enterTempLB;
        private System.Windows.Forms.Label convertedTempLB;
    }
}

