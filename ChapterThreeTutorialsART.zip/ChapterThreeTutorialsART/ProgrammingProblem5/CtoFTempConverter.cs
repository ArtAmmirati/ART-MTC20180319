﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProgrammingProblem5
{
    public partial class CtoFTempConverter : Form
    {
        public CtoFTempConverter()
        {
            InitializeComponent();
        }

        private void clearBTN_Click(object sender, EventArgs e)
        {
            // clear boxes
            inputTempTB.Text = "";
            outputTempLB.Text = "";
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void toFahrenheitBTN_Click(object sender, EventArgs e)
        {
            try
            {
                //declare variables
                decimal tempInput; // input temp
                decimal tempOutput; //converted temp;

                // get temperature input
                tempInput = decimal.Parse(inputTempTB.Text);

                // calculate fahrenheit temp
                tempOutput = ((tempInput * 9)/ 5) + 32;

                // display in converted box
                outputTempLB.Text = tempOutput.ToString("n2") + " "+ "degrees Fahrenheit";
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void toCelsiusBTN_Click(object sender, EventArgs e)
        {
            try
            {
                //declare variables
                decimal tempInput; // input temp
                decimal tempOutput; //converted temp;

                // get temperature input
                tempInput = decimal.Parse(inputTempTB.Text);

                // calculate Celsius temp
                tempOutput = ((tempInput - 32) * 5)/9 ;

                // display in converted box
                outputTempLB.Text = tempOutput.ToString("n2") + " " + "degrees Celsius";
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void exitBTN_Click(object sender, EventArgs e)
        {
            //close form
            this.Close();
        }
    }
}
