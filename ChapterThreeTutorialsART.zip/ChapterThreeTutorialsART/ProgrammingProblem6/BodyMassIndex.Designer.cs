﻿namespace ProgrammingProblem6
{
    partial class BodyMassIndex
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.calculateBTN = new System.Windows.Forms.Button();
            this.clearBTN = new System.Windows.Forms.Button();
            this.exitBTN = new System.Windows.Forms.Button();
            this.inWeightTB = new System.Windows.Forms.TextBox();
            this.inHeightTB = new System.Windows.Forms.TextBox();
            this.weightLB = new System.Windows.Forms.Label();
            this.heightLB = new System.Windows.Forms.Label();
            this.bmiLB = new System.Windows.Forms.Label();
            this.outBmiLB = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // calculateBTN
            // 
            this.calculateBTN.Location = new System.Drawing.Point(79, 185);
            this.calculateBTN.Name = "calculateBTN";
            this.calculateBTN.Size = new System.Drawing.Size(120, 23);
            this.calculateBTN.TabIndex = 3;
            this.calculateBTN.Text = "CALCULATE";
            this.calculateBTN.UseVisualStyleBackColor = true;
            this.calculateBTN.Click += new System.EventHandler(this.calculateBTN_Click);
            // 
            // clearBTN
            // 
            this.clearBTN.Location = new System.Drawing.Point(35, 226);
            this.clearBTN.Name = "clearBTN";
            this.clearBTN.Size = new System.Drawing.Size(75, 23);
            this.clearBTN.TabIndex = 4;
            this.clearBTN.Text = "CLEAR";
            this.clearBTN.UseVisualStyleBackColor = true;
            this.clearBTN.Click += new System.EventHandler(this.clearBTN_Click);
            // 
            // exitBTN
            // 
            this.exitBTN.Location = new System.Drawing.Point(155, 226);
            this.exitBTN.Name = "exitBTN";
            this.exitBTN.Size = new System.Drawing.Size(75, 23);
            this.exitBTN.TabIndex = 5;
            this.exitBTN.Text = "EXIT";
            this.exitBTN.UseVisualStyleBackColor = true;
            this.exitBTN.Click += new System.EventHandler(this.button3_Click);
            // 
            // inWeightTB
            // 
            this.inWeightTB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.inWeightTB.Location = new System.Drawing.Point(155, 13);
            this.inWeightTB.Name = "inWeightTB";
            this.inWeightTB.Size = new System.Drawing.Size(100, 20);
            this.inWeightTB.TabIndex = 0;
            this.inWeightTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // inHeightTB
            // 
            this.inHeightTB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.inHeightTB.Location = new System.Drawing.Point(155, 49);
            this.inHeightTB.Name = "inHeightTB";
            this.inHeightTB.Size = new System.Drawing.Size(100, 20);
            this.inHeightTB.TabIndex = 1;
            this.inHeightTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // weightLB
            // 
            this.weightLB.AutoSize = true;
            this.weightLB.Location = new System.Drawing.Point(13, 19);
            this.weightLB.Name = "weightLB";
            this.weightLB.Size = new System.Drawing.Size(100, 13);
            this.weightLB.TabIndex = 6;
            this.weightLB.Text = "Enter Weight ( lbs ):";
            // 
            // heightLB
            // 
            this.heightLB.AutoSize = true;
            this.heightLB.Location = new System.Drawing.Point(16, 55);
            this.heightLB.Name = "heightLB";
            this.heightLB.Size = new System.Drawing.Size(115, 13);
            this.heightLB.TabIndex = 7;
            this.heightLB.Text = "Enter Height ( inches ):";
            // 
            // bmiLB
            // 
            this.bmiLB.AutoSize = true;
            this.bmiLB.Location = new System.Drawing.Point(19, 101);
            this.bmiLB.Name = "bmiLB";
            this.bmiLB.Size = new System.Drawing.Size(91, 13);
            this.bmiLB.TabIndex = 8;
            this.bmiLB.Text = "Body Mass Index:";
            // 
            // outBmiLB
            // 
            this.outBmiLB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outBmiLB.Location = new System.Drawing.Point(155, 91);
            this.outBmiLB.Name = "outBmiLB";
            this.outBmiLB.Size = new System.Drawing.Size(100, 23);
            this.outBmiLB.TabIndex = 2;
            this.outBmiLB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BodyMassIndex
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(267, 261);
            this.Controls.Add(this.outBmiLB);
            this.Controls.Add(this.bmiLB);
            this.Controls.Add(this.heightLB);
            this.Controls.Add(this.weightLB);
            this.Controls.Add(this.inHeightTB);
            this.Controls.Add(this.inWeightTB);
            this.Controls.Add(this.exitBTN);
            this.Controls.Add(this.clearBTN);
            this.Controls.Add(this.calculateBTN);
            this.Name = "BodyMassIndex";
            this.Text = "BMI Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button calculateBTN;
        private System.Windows.Forms.Button clearBTN;
        private System.Windows.Forms.Button exitBTN;
        private System.Windows.Forms.TextBox inWeightTB;
        private System.Windows.Forms.TextBox inHeightTB;
        private System.Windows.Forms.Label weightLB;
        private System.Windows.Forms.Label heightLB;
        private System.Windows.Forms.Label bmiLB;
        private System.Windows.Forms.Label outBmiLB;
    }
}

