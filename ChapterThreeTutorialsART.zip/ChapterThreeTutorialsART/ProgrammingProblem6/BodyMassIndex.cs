﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProgrammingProblem6
{
    public partial class BodyMassIndex : Form
    {
        public BodyMassIndex()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // close form
            this.Close();

            // set focus
            inWeightTB.Focus();
        }

        private void calculateBTN_Click(object sender, EventArgs e)
        {
            try
            {
                // declare variables
                double weight; // to hold weight of person
                double height; // to hold height of person
                double bmi;    // holds BMI

                // assign variables
                weight = double.Parse(inWeightTB.Text);
                height = double.Parse(inHeightTB.Text);

                // calculations
                bmi = (703 * weight) / (height * height);

                //Display the BMI
                outBmiLB.Text = bmi.ToString("n2");
                inWeightTB.Text = weight.ToString() + " " + "Pounds";
                inHeightTB.Text = height.ToString() + " " + "Inches";







            }
            catch (Exception ex)
            {
                //display error message
                MessageBox.Show(ex.Message);
            }
        }

        private void clearBTN_Click(object sender, EventArgs e)
        {
            // clear input and output controls
            inWeightTB.Text = "";
            inHeightTB.Text = "";
            outBmiLB.Text = "";
        }
    }
}
