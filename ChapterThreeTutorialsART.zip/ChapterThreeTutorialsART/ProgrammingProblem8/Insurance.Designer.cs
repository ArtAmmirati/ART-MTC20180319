﻿namespace ProgrammingProblem8
{
    partial class Insurance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.replaceAmtLB = new System.Windows.Forms.Label();
            this.insureAmtLB = new System.Windows.Forms.Label();
            this.inReplaceCostTB = new System.Windows.Forms.TextBox();
            this.outInsuranceAmtLB = new System.Windows.Forms.Label();
            this.calculateBTN = new System.Windows.Forms.Button();
            this.clearBTN = new System.Windows.Forms.Button();
            this.ExitBTN = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // replaceAmtLB
            // 
            this.replaceAmtLB.AutoSize = true;
            this.replaceAmtLB.Location = new System.Drawing.Point(13, 13);
            this.replaceAmtLB.Name = "replaceAmtLB";
            this.replaceAmtLB.Size = new System.Drawing.Size(109, 13);
            this.replaceAmtLB.TabIndex = 0;
            this.replaceAmtLB.Text = "Replacement Amount";
            // 
            // insureAmtLB
            // 
            this.insureAmtLB.AutoSize = true;
            this.insureAmtLB.Location = new System.Drawing.Point(16, 50);
            this.insureAmtLB.Name = "insureAmtLB";
            this.insureAmtLB.Size = new System.Drawing.Size(142, 13);
            this.insureAmtLB.TabIndex = 1;
            this.insureAmtLB.Text = "Insurance Coverage Amount";
            // 
            // inReplaceCostTB
            // 
            this.inReplaceCostTB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.inReplaceCostTB.Location = new System.Drawing.Point(197, 10);
            this.inReplaceCostTB.Name = "inReplaceCostTB";
            this.inReplaceCostTB.Size = new System.Drawing.Size(100, 20);
            this.inReplaceCostTB.TabIndex = 2;
            this.inReplaceCostTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // outInsuranceAmtLB
            // 
            this.outInsuranceAmtLB.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.outInsuranceAmtLB.Location = new System.Drawing.Point(197, 43);
            this.outInsuranceAmtLB.Name = "outInsuranceAmtLB";
            this.outInsuranceAmtLB.Size = new System.Drawing.Size(100, 26);
            this.outInsuranceAmtLB.TabIndex = 3;
            this.outInsuranceAmtLB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // calculateBTN
            // 
            this.calculateBTN.Location = new System.Drawing.Point(12, 124);
            this.calculateBTN.Name = "calculateBTN";
            this.calculateBTN.Size = new System.Drawing.Size(75, 31);
            this.calculateBTN.TabIndex = 4;
            this.calculateBTN.Text = "Calculate";
            this.calculateBTN.UseVisualStyleBackColor = true;
            this.calculateBTN.Click += new System.EventHandler(this.calculateBTN_Click);
            // 
            // clearBTN
            // 
            this.clearBTN.Location = new System.Drawing.Point(125, 124);
            this.clearBTN.Name = "clearBTN";
            this.clearBTN.Size = new System.Drawing.Size(75, 31);
            this.clearBTN.TabIndex = 5;
            this.clearBTN.Text = "CLEAR";
            this.clearBTN.UseVisualStyleBackColor = true;
            this.clearBTN.Click += new System.EventHandler(this.clearBTN_Click);
            // 
            // ExitBTN
            // 
            this.ExitBTN.Location = new System.Drawing.Point(238, 124);
            this.ExitBTN.Name = "ExitBTN";
            this.ExitBTN.Size = new System.Drawing.Size(75, 31);
            this.ExitBTN.TabIndex = 6;
            this.ExitBTN.Text = "EXIT";
            this.ExitBTN.UseVisualStyleBackColor = true;
            this.ExitBTN.Click += new System.EventHandler(this.ExitBTN_Click);
            // 
            // Insurance
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(326, 190);
            this.Controls.Add(this.ExitBTN);
            this.Controls.Add(this.clearBTN);
            this.Controls.Add(this.calculateBTN);
            this.Controls.Add(this.outInsuranceAmtLB);
            this.Controls.Add(this.inReplaceCostTB);
            this.Controls.Add(this.insureAmtLB);
            this.Controls.Add(this.replaceAmtLB);
            this.Name = "Insurance";
            this.Text = "Insurance Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label replaceAmtLB;
        private System.Windows.Forms.Label insureAmtLB;
        private System.Windows.Forms.TextBox inReplaceCostTB;
        private System.Windows.Forms.Label outInsuranceAmtLB;
        private System.Windows.Forms.Button calculateBTN;
        private System.Windows.Forms.Button clearBTN;
        private System.Windows.Forms.Button ExitBTN;
    }
}

