﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProgrammingProblem8
{
    public partial class Insurance : Form
    {
        public Insurance()
        {
            InitializeComponent();
        }

        private void clearBTN_Click(object sender, EventArgs e)
        {
            //clear controls
            inReplaceCostTB.Text = "";
            outInsuranceAmtLB.Text = "";

            // set focus
            inReplaceCostTB.Focus();
        }

        private void ExitBTN_Click(object sender, EventArgs e)
        {
            // close form
            this.Close();
        }

        private void calculateBTN_Click(object sender, EventArgs e)
        {
            try
            {
                // declare variables
                decimal replaceCost;
                decimal insuranceAmt;
                decimal percentage = .80m;


                //string to decimal
                replaceCost = decimal.Parse(inReplaceCostTB.Text);
                percentage = decimal.Parse(percentage.ToString());
                insuranceAmt = replaceCost * percentage;
                // display string as money
                inReplaceCostTB.Text = replaceCost.ToString("C");
                outInsuranceAmtLB.Text = insuranceAmt.ToString("C");
            }
            catch (Exception ex)
            {
                // display exception message
                MessageBox.Show(ex.Message);
            }




        }
    }
}
