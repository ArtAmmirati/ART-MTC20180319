﻿namespace ProgrammingProblem9
{
    partial class CookieCalories
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.calculateBTN = new System.Windows.Forms.Button();
            this.exitBTN = new System.Windows.Forms.Button();
            this.enterCookieLB = new System.Windows.Forms.Label();
            this.totalCaloriesLB = new System.Windows.Forms.Label();
            this.outputCaloriesLB = new System.Windows.Forms.Label();
            this.inputCookieNumberTB = new System.Windows.Forms.TextBox();
            this.clearBTN = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // calculateBTN
            // 
            this.calculateBTN.Location = new System.Drawing.Point(13, 110);
            this.calculateBTN.Name = "calculateBTN";
            this.calculateBTN.Size = new System.Drawing.Size(75, 23);
            this.calculateBTN.TabIndex = 0;
            this.calculateBTN.Text = "Calculate";
            this.calculateBTN.UseVisualStyleBackColor = true;
            this.calculateBTN.Click += new System.EventHandler(this.calculateBTN_Click);
            // 
            // exitBTN
            // 
            this.exitBTN.Location = new System.Drawing.Point(205, 110);
            this.exitBTN.Name = "exitBTN";
            this.exitBTN.Size = new System.Drawing.Size(75, 23);
            this.exitBTN.TabIndex = 2;
            this.exitBTN.Text = "Exit";
            this.exitBTN.UseVisualStyleBackColor = true;
            this.exitBTN.Click += new System.EventHandler(this.exitBTN_Click);
            // 
            // enterCookieLB
            // 
            this.enterCookieLB.AutoSize = true;
            this.enterCookieLB.Location = new System.Drawing.Point(13, 24);
            this.enterCookieLB.Name = "enterCookieLB";
            this.enterCookieLB.Size = new System.Drawing.Size(143, 13);
            this.enterCookieLB.TabIndex = 3;
            this.enterCookieLB.Text = "Enter the number of cookies:";
            // 
            // totalCaloriesLB
            // 
            this.totalCaloriesLB.AutoSize = true;
            this.totalCaloriesLB.Location = new System.Drawing.Point(13, 58);
            this.totalCaloriesLB.Name = "totalCaloriesLB";
            this.totalCaloriesLB.Size = new System.Drawing.Size(74, 13);
            this.totalCaloriesLB.TabIndex = 4;
            this.totalCaloriesLB.Text = "Total Calories:";
            // 
            // outputCaloriesLB
            // 
            this.outputCaloriesLB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputCaloriesLB.Location = new System.Drawing.Point(188, 57);
            this.outputCaloriesLB.Name = "outputCaloriesLB";
            this.outputCaloriesLB.Size = new System.Drawing.Size(91, 23);
            this.outputCaloriesLB.TabIndex = 5;
            this.outputCaloriesLB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // inputCookieNumberTB
            // 
            this.inputCookieNumberTB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.inputCookieNumberTB.Location = new System.Drawing.Point(188, 21);
            this.inputCookieNumberTB.Name = "inputCookieNumberTB";
            this.inputCookieNumberTB.Size = new System.Drawing.Size(91, 20);
            this.inputCookieNumberTB.TabIndex = 6;
            this.inputCookieNumberTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.inputCookieNumberTB.TextChanged += new System.EventHandler(this.inputCookieNumberTB_TextChanged);
            // 
            // clearBTN
            // 
            this.clearBTN.Location = new System.Drawing.Point(108, 109);
            this.clearBTN.Name = "clearBTN";
            this.clearBTN.Size = new System.Drawing.Size(75, 23);
            this.clearBTN.TabIndex = 7;
            this.clearBTN.Text = "Clear";
            this.clearBTN.UseVisualStyleBackColor = true;
            this.clearBTN.Click += new System.EventHandler(this.clearBTN_Click);
            // 
            // CookieCalories
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(294, 149);
            this.Controls.Add(this.clearBTN);
            this.Controls.Add(this.inputCookieNumberTB);
            this.Controls.Add(this.outputCaloriesLB);
            this.Controls.Add(this.totalCaloriesLB);
            this.Controls.Add(this.enterCookieLB);
            this.Controls.Add(this.exitBTN);
            this.Controls.Add(this.calculateBTN);
            this.Name = "CookieCalories";
            this.Text = "Cookie Calories";
            this.Load += new System.EventHandler(this.CookieCalories_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button calculateBTN;
        private System.Windows.Forms.Button exitBTN;
        private System.Windows.Forms.Label enterCookieLB;
        private System.Windows.Forms.Label totalCaloriesLB;
        private System.Windows.Forms.Label outputCaloriesLB;
        private System.Windows.Forms.TextBox inputCookieNumberTB;
        private System.Windows.Forms.Button clearBTN;
    }
}

