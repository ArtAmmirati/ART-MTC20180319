﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProgrammingProblem9
{
    public partial class CookieCalories : Form
    {
        public CookieCalories()
        {
            InitializeComponent();
        }

        private void calculateBTN_Click(object sender, EventArgs e)
        {
            try
            {
                //declare variables
                decimal cookies;
                decimal calories = 75;
                decimal totalCalories;

                // define variables
                cookies = decimal.Parse(inputCookieNumberTB.Text);

                totalCalories = cookies * calories;

                //display results
                outputCaloriesLB.Text = totalCalories.ToString();

                

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void CookieCalories_Load(object sender, EventArgs e)
        {

        }

        private void inputCookieNumberTB_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void clearBTN_Click(object sender, EventArgs e)
        {// clear boxes
            inputCookieNumberTB.Text = "";
            outputCaloriesLB.Text = "";

            // set the focus
            inputCookieNumberTB.Focus();
        }

        private void exitBTN_Click(object sender, EventArgs e)
        {
            //clear form
            this.Close();
        }
    }
}
