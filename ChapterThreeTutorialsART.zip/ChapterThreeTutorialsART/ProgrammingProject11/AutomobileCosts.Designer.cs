﻿namespace ProgrammingProject11
{
    partial class AutomobileCosts
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelLoanPmtLB = new System.Windows.Forms.Label();
            this.labelInsuranceLB = new System.Windows.Forms.Label();
            this.labelGasLB = new System.Windows.Forms.Label();
            this.labelOilLB = new System.Windows.Forms.Label();
            this.labelTiresLB = new System.Windows.Forms.Label();
            this.labelMaintanceLB = new System.Windows.Forms.Label();
            this.labelMonthlyTotalLB = new System.Windows.Forms.Label();
            this.labelYearlyTotalLB = new System.Windows.Forms.Label();
            this.outTotalMonthLB = new System.Windows.Forms.Label();
            this.outTotalYearLB = new System.Windows.Forms.Label();
            this.inLoanTB = new System.Windows.Forms.TextBox();
            this.inInsuranceTB = new System.Windows.Forms.TextBox();
            this.inGasTB = new System.Windows.Forms.TextBox();
            this.inTireTB = new System.Windows.Forms.TextBox();
            this.inMaintanceTB = new System.Windows.Forms.TextBox();
            this.inOilTB = new System.Windows.Forms.TextBox();
            this.calculateBTN = new System.Windows.Forms.Button();
            this.clearBTN = new System.Windows.Forms.Button();
            this.exitBTN = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelLoanPmtLB
            // 
            this.labelLoanPmtLB.AutoSize = true;
            this.labelLoanPmtLB.Location = new System.Drawing.Point(48, 58);
            this.labelLoanPmtLB.Name = "labelLoanPmtLB";
            this.labelLoanPmtLB.Size = new System.Drawing.Size(78, 13);
            this.labelLoanPmtLB.TabIndex = 11;
            this.labelLoanPmtLB.Text = "Loan Payment:";
            // 
            // labelInsuranceLB
            // 
            this.labelInsuranceLB.AutoSize = true;
            this.labelInsuranceLB.Location = new System.Drawing.Point(48, 91);
            this.labelInsuranceLB.Name = "labelInsuranceLB";
            this.labelInsuranceLB.Size = new System.Drawing.Size(101, 13);
            this.labelInsuranceLB.TabIndex = 12;
            this.labelInsuranceLB.Text = "Insurance Payment:";
            // 
            // labelGasLB
            // 
            this.labelGasLB.AutoSize = true;
            this.labelGasLB.Location = new System.Drawing.Point(48, 124);
            this.labelGasLB.Name = "labelGasLB";
            this.labelGasLB.Size = new System.Drawing.Size(58, 13);
            this.labelGasLB.TabIndex = 13;
            this.labelGasLB.Text = "Gas Costs:";
            this.labelGasLB.Click += new System.EventHandler(this.label3_Click);
            // 
            // labelOilLB
            // 
            this.labelOilLB.AutoSize = true;
            this.labelOilLB.Location = new System.Drawing.Point(48, 157);
            this.labelOilLB.Name = "labelOilLB";
            this.labelOilLB.Size = new System.Drawing.Size(56, 13);
            this.labelOilLB.TabIndex = 14;
            this.labelOilLB.Text = "Tires cost:";
            // 
            // labelTiresLB
            // 
            this.labelTiresLB.AutoSize = true;
            this.labelTiresLB.Location = new System.Drawing.Point(48, 190);
            this.labelTiresLB.Name = "labelTiresLB";
            this.labelTiresLB.Size = new System.Drawing.Size(95, 13);
            this.labelTiresLB.TabIndex = 15;
            this.labelTiresLB.Text = "Maintenance cost:";
            // 
            // labelMaintanceLB
            // 
            this.labelMaintanceLB.AutoSize = true;
            this.labelMaintanceLB.Location = new System.Drawing.Point(48, 223);
            this.labelMaintanceLB.Name = "labelMaintanceLB";
            this.labelMaintanceLB.Size = new System.Drawing.Size(45, 13);
            this.labelMaintanceLB.TabIndex = 16;
            this.labelMaintanceLB.Text = "Oil cost:";
            // 
            // labelMonthlyTotalLB
            // 
            this.labelMonthlyTotalLB.AutoSize = true;
            this.labelMonthlyTotalLB.Location = new System.Drawing.Point(48, 265);
            this.labelMonthlyTotalLB.Name = "labelMonthlyTotalLB";
            this.labelMonthlyTotalLB.Size = new System.Drawing.Size(118, 13);
            this.labelMonthlyTotalLB.TabIndex = 17;
            this.labelMonthlyTotalLB.Text = "Total Monthly Expense:";
            this.labelMonthlyTotalLB.Click += new System.EventHandler(this.labelMonthlyTotalLB_Click);
            // 
            // labelYearlyTotalLB
            // 
            this.labelYearlyTotalLB.AutoSize = true;
            this.labelYearlyTotalLB.Location = new System.Drawing.Point(48, 291);
            this.labelYearlyTotalLB.Name = "labelYearlyTotalLB";
            this.labelYearlyTotalLB.Size = new System.Drawing.Size(110, 13);
            this.labelYearlyTotalLB.TabIndex = 18;
            this.labelYearlyTotalLB.Text = "Total Yearly Expense:";
            this.labelYearlyTotalLB.Click += new System.EventHandler(this.labelYearlyTotalLB_Click);
            // 
            // outTotalMonthLB
            // 
            this.outTotalMonthLB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outTotalMonthLB.Location = new System.Drawing.Point(227, 255);
            this.outTotalMonthLB.Name = "outTotalMonthLB";
            this.outTotalMonthLB.Size = new System.Drawing.Size(100, 23);
            this.outTotalMonthLB.TabIndex = 6;
            this.outTotalMonthLB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.outTotalMonthLB.Click += new System.EventHandler(this.outTotalMonthLB_Click);
            // 
            // outTotalYearLB
            // 
            this.outTotalYearLB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outTotalYearLB.Location = new System.Drawing.Point(227, 281);
            this.outTotalYearLB.Name = "outTotalYearLB";
            this.outTotalYearLB.Size = new System.Drawing.Size(100, 23);
            this.outTotalYearLB.TabIndex = 7;
            this.outTotalYearLB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.outTotalYearLB.Click += new System.EventHandler(this.outTotalYearLB_Click);
            // 
            // inLoanTB
            // 
            this.inLoanTB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.inLoanTB.Location = new System.Drawing.Point(227, 58);
            this.inLoanTB.Name = "inLoanTB";
            this.inLoanTB.Size = new System.Drawing.Size(100, 20);
            this.inLoanTB.TabIndex = 0;
            this.inLoanTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // inInsuranceTB
            // 
            this.inInsuranceTB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.inInsuranceTB.Location = new System.Drawing.Point(227, 91);
            this.inInsuranceTB.Name = "inInsuranceTB";
            this.inInsuranceTB.Size = new System.Drawing.Size(100, 20);
            this.inInsuranceTB.TabIndex = 1;
            this.inInsuranceTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.inInsuranceTB.TextChanged += new System.EventHandler(this.inInsuranceTB_TextChanged);
            // 
            // inGasTB
            // 
            this.inGasTB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.inGasTB.Location = new System.Drawing.Point(227, 124);
            this.inGasTB.Name = "inGasTB";
            this.inGasTB.Size = new System.Drawing.Size(100, 20);
            this.inGasTB.TabIndex = 2;
            this.inGasTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // inTireTB
            // 
            this.inTireTB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.inTireTB.Location = new System.Drawing.Point(227, 157);
            this.inTireTB.Name = "inTireTB";
            this.inTireTB.Size = new System.Drawing.Size(100, 20);
            this.inTireTB.TabIndex = 3;
            this.inTireTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // inMaintanceTB
            // 
            this.inMaintanceTB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.inMaintanceTB.Location = new System.Drawing.Point(227, 190);
            this.inMaintanceTB.Name = "inMaintanceTB";
            this.inMaintanceTB.Size = new System.Drawing.Size(100, 20);
            this.inMaintanceTB.TabIndex = 4;
            this.inMaintanceTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // inOilTB
            // 
            this.inOilTB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.inOilTB.Location = new System.Drawing.Point(227, 223);
            this.inOilTB.Name = "inOilTB";
            this.inOilTB.Size = new System.Drawing.Size(100, 20);
            this.inOilTB.TabIndex = 5;
            this.inOilTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // calculateBTN
            // 
            this.calculateBTN.Location = new System.Drawing.Point(412, 114);
            this.calculateBTN.Name = "calculateBTN";
            this.calculateBTN.Size = new System.Drawing.Size(75, 23);
            this.calculateBTN.TabIndex = 8;
            this.calculateBTN.Text = "&Calculate";
            this.calculateBTN.UseVisualStyleBackColor = true;
            this.calculateBTN.Click += new System.EventHandler(this.calculateBTN_Click);
            // 
            // clearBTN
            // 
            this.clearBTN.Location = new System.Drawing.Point(412, 168);
            this.clearBTN.Name = "clearBTN";
            this.clearBTN.Size = new System.Drawing.Size(75, 23);
            this.clearBTN.TabIndex = 9;
            this.clearBTN.Text = "&ERASE";
            this.clearBTN.UseVisualStyleBackColor = true;
            this.clearBTN.Click += new System.EventHandler(this.clearBTN_Click);
            // 
            // exitBTN
            // 
            this.exitBTN.Location = new System.Drawing.Point(412, 222);
            this.exitBTN.Name = "exitBTN";
            this.exitBTN.Size = new System.Drawing.Size(75, 23);
            this.exitBTN.TabIndex = 10;
            this.exitBTN.Text = "E&XIT";
            this.exitBTN.UseVisualStyleBackColor = true;
            this.exitBTN.Click += new System.EventHandler(this.exitBTN_Click);
            // 
            // AutomobileCosts
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(514, 376);
            this.Controls.Add(this.exitBTN);
            this.Controls.Add(this.clearBTN);
            this.Controls.Add(this.calculateBTN);
            this.Controls.Add(this.inOilTB);
            this.Controls.Add(this.inMaintanceTB);
            this.Controls.Add(this.inTireTB);
            this.Controls.Add(this.inGasTB);
            this.Controls.Add(this.inInsuranceTB);
            this.Controls.Add(this.inLoanTB);
            this.Controls.Add(this.outTotalYearLB);
            this.Controls.Add(this.outTotalMonthLB);
            this.Controls.Add(this.labelYearlyTotalLB);
            this.Controls.Add(this.labelMonthlyTotalLB);
            this.Controls.Add(this.labelMaintanceLB);
            this.Controls.Add(this.labelTiresLB);
            this.Controls.Add(this.labelOilLB);
            this.Controls.Add(this.labelGasLB);
            this.Controls.Add(this.labelInsuranceLB);
            this.Controls.Add(this.labelLoanPmtLB);
            this.Name = "AutomobileCosts";
            this.Text = "Automobile Costs";
            this.Load += new System.EventHandler(this.AutomobileCosts_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelLoanPmtLB;
        private System.Windows.Forms.Label labelInsuranceLB;
        private System.Windows.Forms.Label labelGasLB;
        private System.Windows.Forms.Label labelOilLB;
        private System.Windows.Forms.Label labelTiresLB;
        private System.Windows.Forms.Label labelMaintanceLB;
        private System.Windows.Forms.Label labelMonthlyTotalLB;
        private System.Windows.Forms.Label labelYearlyTotalLB;
        private System.Windows.Forms.Label outTotalMonthLB;
        private System.Windows.Forms.Label outTotalYearLB;
        private System.Windows.Forms.TextBox inLoanTB;
        private System.Windows.Forms.TextBox inInsuranceTB;
        private System.Windows.Forms.TextBox inGasTB;
        private System.Windows.Forms.TextBox inTireTB;
        private System.Windows.Forms.TextBox inMaintanceTB;
        private System.Windows.Forms.TextBox inOilTB;
        private System.Windows.Forms.Button calculateBTN;
        private System.Windows.Forms.Button clearBTN;
        private System.Windows.Forms.Button exitBTN;
    }
}

