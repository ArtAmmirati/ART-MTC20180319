﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProgrammingProject11
{
    public partial class AutomobileCosts : Form
    {
        public AutomobileCosts()
        {
            InitializeComponent();
        }

        private void AutomobileCosts_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void labelYearlyTotalLB_Click(object sender, EventArgs e)
        {

        }

        private void outTotalMonthLB_Click(object sender, EventArgs e)
        {

        


               
        }

        private void outTotalYearLB_Click(object sender, EventArgs e)
        {

        }

        private void labelMonthlyTotalLB_Click(object sender, EventArgs e)
        {

        }

        private void calculateBTN_Click(object sender, EventArgs e)
        {
            try
            {
                // declare varaiables
                double loan;
                double insurance;
                double gas;
                double oil;
                double tires;
                double maintenance;
                double monthlyTotal;
                double yearlyTotal;

                //convert string to numeric

                loan = double.Parse(inLoanTB.Text);
                insurance = double.Parse(inInsuranceTB.Text);
                gas = double.Parse(inGasTB.Text);
                oil = double.Parse(inOilTB.Text);
                tires = double.Parse(inTireTB.Text);
                maintenance = double.Parse(inMaintanceTB.Text);
                //  monthlyTotal = double.Parse(outTotalMonthLB.Text);
                //  yearlyTotal = double.Parse(outTotalYearLB.Text);

                // calculations for totals
                monthlyTotal = loan + insurance + gas + oil + tires + maintenance;
                yearlyTotal = monthlyTotal * 12;

                // display total
                outTotalMonthLB.Text = monthlyTotal.ToString("C");
                outTotalYearLB.Text = yearlyTotal.ToString("C");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void clearBTN_Click(object sender, EventArgs e)
        {
            // clear all input and totals cells

            inLoanTB.Text = "";
            inInsuranceTB.Text = "";
            inGasTB.Text = "";
            inOilTB.Text = "";
            inTireTB.Text = "";
            inMaintanceTB.Text = "";
            outTotalMonthLB.Text = "";
            outTotalYearLB.Text = "";

            // set the focus to inloanTB
            inLoanTB.Focus();
        }

        private void inInsuranceTB_TextChanged(object sender, EventArgs e)
        {

        }

        private void exitBTN_Click(object sender, EventArgs e)
        {
            // close form
            this.Close();
        }
    }
}
