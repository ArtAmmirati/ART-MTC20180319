﻿namespace ProgrammingProject13
{
    partial class PropertyTaxCalculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.calculateBTN = new System.Windows.Forms.Button();
            this.clearBTN = new System.Windows.Forms.Button();
            this.exitBTN = new System.Windows.Forms.Button();
            this.LabelPropertyValueLB = new System.Windows.Forms.Label();
            this.labelPropertyTaxLB = new System.Windows.Forms.Label();
            this.outPropertyTaxLB = new System.Windows.Forms.Label();
            this.inPropertyValueTB = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // calculateBTN
            // 
            this.calculateBTN.Location = new System.Drawing.Point(12, 146);
            this.calculateBTN.Name = "calculateBTN";
            this.calculateBTN.Size = new System.Drawing.Size(94, 23);
            this.calculateBTN.TabIndex = 2;
            this.calculateBTN.Text = "CALCULATE";
            this.calculateBTN.UseVisualStyleBackColor = true;
            this.calculateBTN.Click += new System.EventHandler(this.calculateBTN_Click);
            // 
            // clearBTN
            // 
            this.clearBTN.Location = new System.Drawing.Point(131, 146);
            this.clearBTN.Name = "clearBTN";
            this.clearBTN.Size = new System.Drawing.Size(94, 23);
            this.clearBTN.TabIndex = 3;
            this.clearBTN.Text = "CLEAR";
            this.clearBTN.UseVisualStyleBackColor = true;
            this.clearBTN.Click += new System.EventHandler(this.clearBTN_Click);
            // 
            // exitBTN
            // 
            this.exitBTN.Location = new System.Drawing.Point(250, 146);
            this.exitBTN.Name = "exitBTN";
            this.exitBTN.Size = new System.Drawing.Size(94, 23);
            this.exitBTN.TabIndex = 4;
            this.exitBTN.Text = "EXIT";
            this.exitBTN.UseVisualStyleBackColor = true;
            this.exitBTN.Click += new System.EventHandler(this.exitBTN_Click);
            // 
            // LabelPropertyValueLB
            // 
            this.LabelPropertyValueLB.AutoSize = true;
            this.LabelPropertyValueLB.Location = new System.Drawing.Point(22, 15);
            this.LabelPropertyValueLB.Name = "LabelPropertyValueLB";
            this.LabelPropertyValueLB.Size = new System.Drawing.Size(155, 26);
            this.LabelPropertyValueLB.TabIndex = 5;
            this.LabelPropertyValueLB.Text = "Enter the Value of the Property:\r\n\r\n";
            // 
            // labelPropertyTaxLB
            // 
            this.labelPropertyTaxLB.AutoSize = true;
            this.labelPropertyTaxLB.Location = new System.Drawing.Point(22, 62);
            this.labelPropertyTaxLB.Name = "labelPropertyTaxLB";
            this.labelPropertyTaxLB.Size = new System.Drawing.Size(154, 13);
            this.labelPropertyTaxLB.TabIndex = 6;
            this.labelPropertyTaxLB.Text = "Calculated Property Tax Owed:";
            // 
            // outPropertyTaxLB
            // 
            this.outPropertyTaxLB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outPropertyTaxLB.Location = new System.Drawing.Point(250, 57);
            this.outPropertyTaxLB.Name = "outPropertyTaxLB";
            this.outPropertyTaxLB.Size = new System.Drawing.Size(100, 23);
            this.outPropertyTaxLB.TabIndex = 1;
            this.outPropertyTaxLB.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // inPropertyValueTB
            // 
            this.inPropertyValueTB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.inPropertyValueTB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.inPropertyValueTB.Location = new System.Drawing.Point(250, 13);
            this.inPropertyValueTB.Name = "inPropertyValueTB";
            this.inPropertyValueTB.Size = new System.Drawing.Size(100, 20);
            this.inPropertyValueTB.TabIndex = 0;
            this.inPropertyValueTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // PropertyTaxCalculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(369, 181);
            this.Controls.Add(this.inPropertyValueTB);
            this.Controls.Add(this.outPropertyTaxLB);
            this.Controls.Add(this.labelPropertyTaxLB);
            this.Controls.Add(this.LabelPropertyValueLB);
            this.Controls.Add(this.exitBTN);
            this.Controls.Add(this.clearBTN);
            this.Controls.Add(this.calculateBTN);
            this.Name = "PropertyTaxCalculator";
            this.Text = "Property Tax Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button calculateBTN;
        private System.Windows.Forms.Button clearBTN;
        private System.Windows.Forms.Button exitBTN;
        private System.Windows.Forms.Label LabelPropertyValueLB;
        private System.Windows.Forms.Label labelPropertyTaxLB;
        private System.Windows.Forms.Label outPropertyTaxLB;
        private System.Windows.Forms.TextBox inPropertyValueTB;
    }
}

