﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProgrammingProject13
{
    public partial class PropertyTaxCalculator : Form
    {
        public PropertyTaxCalculator()
        {
            InitializeComponent();
        }

        private void calculateBTN_Click(object sender, EventArgs e)
        {
            try
            {
                decimal propertyValue; // holds property value
                decimal perHundredAmt; // hold the p.value devided by 100
                decimal propertyTaxfraction; // holds the money value(.64) per 100 dollars
                decimal propertyTaxAmount; // holds the property tax amount

                // converting numeric to strings
                propertyValue = decimal.Parse(inPropertyValueTB.Text);
                
                propertyTaxfraction = decimal.Parse("0.64");

                //calculations
                perHundredAmt = propertyValue / 100;
                propertyTaxAmount = perHundredAmt * propertyTaxfraction;

                // display property tax
                outPropertyTaxLB.Text = propertyTaxAmount.ToString("C");
                inPropertyValueTB.Text = propertyValue.ToString("C");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);

            }



        }

        private void clearBTN_Click(object sender, EventArgs e)
        {
            // clear cells
            inPropertyValueTB.Text = "";
            outPropertyTaxLB.Text = "";

            // set focus
            inPropertyValueTB.Focus();
        }

        private void exitBTN_Click(object sender, EventArgs e)
        {
            //close form
            this.Close();
        }
    }
}
