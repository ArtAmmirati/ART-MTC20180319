﻿namespace Tutorial3_3SalesPriceCalculator
{
    partial class SalesPriceCalculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.originalPricePromptLB = new System.Windows.Forms.Label();
            this.discPercentagePromptLB = new System.Windows.Forms.Label();
            this.outputDescriptionLB = new System.Windows.Forms.Label();
            this.salePriceLB = new System.Windows.Forms.Label();
            this.originalPriceTB = new System.Windows.Forms.TextBox();
            this.discountPercentageTB = new System.Windows.Forms.TextBox();
            this.calculateBTN = new System.Windows.Forms.Button();
            this.exitBTN = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // originalPricePromptLB
            // 
            this.originalPricePromptLB.AutoSize = true;
            this.originalPricePromptLB.Location = new System.Drawing.Point(16, 13);
            this.originalPricePromptLB.Name = "originalPricePromptLB";
            this.originalPricePromptLB.Size = new System.Drawing.Size(144, 13);
            this.originalPricePromptLB.TabIndex = 0;
            this.originalPricePromptLB.Text = "Enter the item\'s original price:";
            // 
            // discPercentagePromptLB
            // 
            this.discPercentagePromptLB.AutoSize = true;
            this.discPercentagePromptLB.Location = new System.Drawing.Point(16, 58);
            this.discPercentagePromptLB.Name = "discPercentagePromptLB";
            this.discPercentagePromptLB.Size = new System.Drawing.Size(153, 13);
            this.discPercentagePromptLB.TabIndex = 1;
            this.discPercentagePromptLB.Text = "Enter the discount percentage:";
            // 
            // outputDescriptionLB
            // 
            this.outputDescriptionLB.AutoSize = true;
            this.outputDescriptionLB.Location = new System.Drawing.Point(16, 103);
            this.outputDescriptionLB.Name = "outputDescriptionLB";
            this.outputDescriptionLB.Size = new System.Drawing.Size(62, 13);
            this.outputDescriptionLB.TabIndex = 2;
            this.outputDescriptionLB.Text = "Sales price:";
            // 
            // salePriceLB
            // 
            this.salePriceLB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.salePriceLB.Location = new System.Drawing.Point(212, 98);
            this.salePriceLB.Name = "salePriceLB";
            this.salePriceLB.Size = new System.Drawing.Size(107, 23);
            this.salePriceLB.TabIndex = 3;
            this.salePriceLB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // originalPriceTB
            // 
            this.originalPriceTB.Location = new System.Drawing.Point(212, 10);
            this.originalPriceTB.Name = "originalPriceTB";
            this.originalPriceTB.Size = new System.Drawing.Size(107, 20);
            this.originalPriceTB.TabIndex = 4;
            // 
            // discountPercentageTB
            // 
            this.discountPercentageTB.Location = new System.Drawing.Point(212, 55);
            this.discountPercentageTB.Name = "discountPercentageTB";
            this.discountPercentageTB.Size = new System.Drawing.Size(107, 20);
            this.discountPercentageTB.TabIndex = 5;
            // 
            // calculateBTN
            // 
            this.calculateBTN.Location = new System.Drawing.Point(19, 175);
            this.calculateBTN.Name = "calculateBTN";
            this.calculateBTN.Size = new System.Drawing.Size(107, 57);
            this.calculateBTN.TabIndex = 6;
            this.calculateBTN.Text = "CALCULATE SALE PRICE";
            this.calculateBTN.UseVisualStyleBackColor = true;
            this.calculateBTN.Click += new System.EventHandler(this.calculateBTN_Click);
            // 
            // exitBTN
            // 
            this.exitBTN.Location = new System.Drawing.Point(212, 175);
            this.exitBTN.Name = "exitBTN";
            this.exitBTN.Size = new System.Drawing.Size(107, 57);
            this.exitBTN.TabIndex = 7;
            this.exitBTN.Text = "EXIT";
            this.exitBTN.UseVisualStyleBackColor = true;
            this.exitBTN.Click += new System.EventHandler(this.exitBTN_Click);
            // 
            // SalesPriceCalculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(331, 261);
            this.Controls.Add(this.exitBTN);
            this.Controls.Add(this.calculateBTN);
            this.Controls.Add(this.discountPercentageTB);
            this.Controls.Add(this.originalPriceTB);
            this.Controls.Add(this.salePriceLB);
            this.Controls.Add(this.outputDescriptionLB);
            this.Controls.Add(this.discPercentagePromptLB);
            this.Controls.Add(this.originalPricePromptLB);
            this.Name = "SalesPriceCalculator";
            this.Text = "Sales Price Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label originalPricePromptLB;
        private System.Windows.Forms.Label discPercentagePromptLB;
        private System.Windows.Forms.Label outputDescriptionLB;
        private System.Windows.Forms.Label salePriceLB;
        private System.Windows.Forms.TextBox originalPriceTB;
        private System.Windows.Forms.TextBox discountPercentageTB;
        private System.Windows.Forms.Button calculateBTN;
        private System.Windows.Forms.Button exitBTN;
    }
}

