﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tutorial3_3SalesPriceCalculator
{
    public partial class SalesPriceCalculator : Form
    {
        public SalesPriceCalculator()
        {
            InitializeComponent();
        }

        private void calculateBTN_Click(object sender, EventArgs e)
        {
            try
            {
                decimal originalPrice;        // the item's original price
                decimal discountPercentage;   // the discount percentage
                decimal discountAmount;       // the amount of discount
                decimal salePrice;            // the item's sale price

                // get the item's original price
                originalPrice = decimal.Parse(originalPriceTB.Text);
                // get the discount percentage
                discountPercentage = decimal.Parse(discountPercentageTB.Text);
                //move the percentage's decimal point left two spaces
                discountPercentage = discountPercentage / 100;
                //calculate the amount of the discount
                discountAmount = originalPrice * discountPercentage;
                //calculate the sale price
                salePrice = originalPrice - discountAmount;
                //display the sale price.
                salePriceLB.Text = salePrice.ToString("c");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void exitBTN_Click(object sender, EventArgs e)
        {
            // close the form
            this.Close();
        }
    }
}
