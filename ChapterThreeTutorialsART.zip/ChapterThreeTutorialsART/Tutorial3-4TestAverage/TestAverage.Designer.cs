﻿namespace Tutorial3_4TestAverage
{
    partial class TestAverage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Test1PromptLB = new System.Windows.Forms.Label();
            this.Test2PromptLB = new System.Windows.Forms.Label();
            this.Test3PromptLB = new System.Windows.Forms.Label();
            this.averageLB = new System.Windows.Forms.Label();
            this.outputDescriptionLB = new System.Windows.Forms.Label();
            this.Test1TB = new System.Windows.Forms.TextBox();
            this.Test2TB = new System.Windows.Forms.TextBox();
            this.Test3TB = new System.Windows.Forms.TextBox();
            this.calculateBTN = new System.Windows.Forms.Button();
            this.clearBTN = new System.Windows.Forms.Button();
            this.exitBTN = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Test1PromptLB
            // 
            this.Test1PromptLB.AutoSize = true;
            this.Test1PromptLB.Location = new System.Drawing.Point(13, 13);
            this.Test1PromptLB.Name = "Test1PromptLB";
            this.Test1PromptLB.Size = new System.Drawing.Size(37, 13);
            this.Test1PromptLB.TabIndex = 0;
            this.Test1PromptLB.Text = "Test 1";
            // 
            // Test2PromptLB
            // 
            this.Test2PromptLB.AutoSize = true;
            this.Test2PromptLB.Location = new System.Drawing.Point(12, 53);
            this.Test2PromptLB.Name = "Test2PromptLB";
            this.Test2PromptLB.Size = new System.Drawing.Size(37, 13);
            this.Test2PromptLB.TabIndex = 1;
            this.Test2PromptLB.Text = "Test 2";
            // 
            // Test3PromptLB
            // 
            this.Test3PromptLB.AutoSize = true;
            this.Test3PromptLB.Location = new System.Drawing.Point(13, 93);
            this.Test3PromptLB.Name = "Test3PromptLB";
            this.Test3PromptLB.Size = new System.Drawing.Size(37, 13);
            this.Test3PromptLB.TabIndex = 2;
            this.Test3PromptLB.Text = "Test 3";
            this.Test3PromptLB.Click += new System.EventHandler(this.Test3PromptLB_Click);
            // 
            // averageLB
            // 
            this.averageLB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.averageLB.Location = new System.Drawing.Point(150, 128);
            this.averageLB.Name = "averageLB";
            this.averageLB.Size = new System.Drawing.Size(123, 23);
            this.averageLB.TabIndex = 3;
            this.averageLB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // outputDescriptionLB
            // 
            this.outputDescriptionLB.AutoSize = true;
            this.outputDescriptionLB.Location = new System.Drawing.Point(12, 133);
            this.outputDescriptionLB.Name = "outputDescriptionLB";
            this.outputDescriptionLB.Size = new System.Drawing.Size(102, 13);
            this.outputDescriptionLB.TabIndex = 4;
            this.outputDescriptionLB.Text = "Average Test Score";
            this.outputDescriptionLB.Click += new System.EventHandler(this.label1_Click);
            // 
            // Test1TB
            // 
            this.Test1TB.Location = new System.Drawing.Point(150, 10);
            this.Test1TB.Name = "Test1TB";
            this.Test1TB.Size = new System.Drawing.Size(123, 20);
            this.Test1TB.TabIndex = 5;
            // 
            // Test2TB
            // 
            this.Test2TB.Location = new System.Drawing.Point(150, 50);
            this.Test2TB.Name = "Test2TB";
            this.Test2TB.Size = new System.Drawing.Size(123, 20);
            this.Test2TB.TabIndex = 6;
            // 
            // Test3TB
            // 
            this.Test3TB.Location = new System.Drawing.Point(150, 90);
            this.Test3TB.Name = "Test3TB";
            this.Test3TB.Size = new System.Drawing.Size(123, 20);
            this.Test3TB.TabIndex = 7;
            // 
            // calculateBTN
            // 
            this.calculateBTN.Location = new System.Drawing.Point(14, 182);
            this.calculateBTN.Name = "calculateBTN";
            this.calculateBTN.Size = new System.Drawing.Size(86, 63);
            this.calculateBTN.TabIndex = 8;
            this.calculateBTN.Text = "CALCULATE AVERGE";
            this.calculateBTN.UseVisualStyleBackColor = true;
            this.calculateBTN.Click += new System.EventHandler(this.calculateBTN_Click);
            // 
            // clearBTN
            // 
            this.clearBTN.Location = new System.Drawing.Point(121, 182);
            this.clearBTN.Name = "clearBTN";
            this.clearBTN.Size = new System.Drawing.Size(75, 63);
            this.clearBTN.TabIndex = 9;
            this.clearBTN.Text = "CLEAR";
            this.clearBTN.UseVisualStyleBackColor = true;
            this.clearBTN.Click += new System.EventHandler(this.clearBTN_Click);
            // 
            // exitBTN
            // 
            this.exitBTN.Location = new System.Drawing.Point(217, 182);
            this.exitBTN.Name = "exitBTN";
            this.exitBTN.Size = new System.Drawing.Size(75, 63);
            this.exitBTN.TabIndex = 10;
            this.exitBTN.Text = "EXIT";
            this.exitBTN.UseVisualStyleBackColor = true;
            this.exitBTN.Click += new System.EventHandler(this.exitBTN_Click);
            // 
            // TestAverage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(307, 257);
            this.Controls.Add(this.exitBTN);
            this.Controls.Add(this.clearBTN);
            this.Controls.Add(this.calculateBTN);
            this.Controls.Add(this.Test3TB);
            this.Controls.Add(this.Test2TB);
            this.Controls.Add(this.Test1TB);
            this.Controls.Add(this.outputDescriptionLB);
            this.Controls.Add(this.averageLB);
            this.Controls.Add(this.Test3PromptLB);
            this.Controls.Add(this.Test2PromptLB);
            this.Controls.Add(this.Test1PromptLB);
            this.Name = "TestAverage";
            this.Text = "Test Average";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Test1PromptLB;
        private System.Windows.Forms.Label Test2PromptLB;
        private System.Windows.Forms.Label Test3PromptLB;
        private System.Windows.Forms.Label averageLB;
        private System.Windows.Forms.Label outputDescriptionLB;
        private System.Windows.Forms.TextBox Test1TB;
        private System.Windows.Forms.TextBox Test2TB;
        private System.Windows.Forms.TextBox Test3TB;
        private System.Windows.Forms.Button calculateBTN;
        private System.Windows.Forms.Button clearBTN;
        private System.Windows.Forms.Button exitBTN;
    }
}

