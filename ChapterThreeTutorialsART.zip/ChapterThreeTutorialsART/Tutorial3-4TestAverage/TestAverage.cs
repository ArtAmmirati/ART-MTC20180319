﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tutorial3_4TestAverage
{
    public partial class TestAverage : Form
    {
        public TestAverage()
        {
            InitializeComponent();
        }

        private void Test3PromptLB_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void calculateBTN_Click(object sender, EventArgs e)
        {
            try
            {
                double test1;   //to hold test score #1
                double test2;   //to hold test score #2
                double test3;   //to hold test score #3
                double average; //to hold the average test score

                //get the three test scores
                test1 = double.Parse(Test1TB.Text);
                test2 = double.Parse(Test2TB.Text);
                test3 = double.Parse(Test3TB.Text);

                //calculate the average test score
                average = (test1 + test2 + test3) / 3.0;

                //display the average test score, with 
                //the output rounded to 1 decimal point
                averageLB.Text = average.ToString("n1");
            }
            catch (Exception ex)
            {
                // display the default error message
                MessageBox.Show(ex.Message);
            }
        }

        private void clearBTN_Click(object sender, EventArgs e)
        {
            //clear the input and output controls
            Test1TB.Text = "";
            Test2TB.Text = "";
            Test3TB.Text = "";
            averageLB.Text = "";

        }

        private void exitBTN_Click(object sender, EventArgs e)
        {
            //close form
            this.Close();
        }
    }
}
