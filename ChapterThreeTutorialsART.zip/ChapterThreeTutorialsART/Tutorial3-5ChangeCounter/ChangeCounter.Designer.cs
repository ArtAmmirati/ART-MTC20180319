﻿namespace Tutorial3_5ChangeCounter
{
    partial class ChangeCounter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ChangeCounter));
            this.fiveCentsPB = new System.Windows.Forms.PictureBox();
            this.twentyFiveCentsPB = new System.Windows.Forms.PictureBox();
            this.tenCentsPB = new System.Windows.Forms.PictureBox();
            this.fiftyCentsPB = new System.Windows.Forms.PictureBox();
            this.instructiionLB = new System.Windows.Forms.Label();
            this.outputInstructionLB = new System.Windows.Forms.Label();
            this.totalLB = new System.Windows.Forms.Label();
            this.exitBTN = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.fiveCentsPB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.twentyFiveCentsPB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tenCentsPB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fiftyCentsPB)).BeginInit();
            this.SuspendLayout();
            // 
            // fiveCentsPB
            // 
            this.fiveCentsPB.Image = ((System.Drawing.Image)(resources.GetObject("fiveCentsPB.Image")));
            this.fiveCentsPB.Location = new System.Drawing.Point(12, 47);
            this.fiveCentsPB.Name = "fiveCentsPB";
            this.fiveCentsPB.Size = new System.Drawing.Size(123, 188);
            this.fiveCentsPB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.fiveCentsPB.TabIndex = 0;
            this.fiveCentsPB.TabStop = false;
            this.fiveCentsPB.Click += new System.EventHandler(this.fiveCentsPB_Click);
            // 
            // twentyFiveCentsPB
            // 
            this.twentyFiveCentsPB.Image = ((System.Drawing.Image)(resources.GetObject("twentyFiveCentsPB.Image")));
            this.twentyFiveCentsPB.Location = new System.Drawing.Point(12, 241);
            this.twentyFiveCentsPB.Name = "twentyFiveCentsPB";
            this.twentyFiveCentsPB.Size = new System.Drawing.Size(123, 187);
            this.twentyFiveCentsPB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.twentyFiveCentsPB.TabIndex = 1;
            this.twentyFiveCentsPB.TabStop = false;
            this.twentyFiveCentsPB.Click += new System.EventHandler(this.twentyFiveCentsPB_Click);
            // 
            // tenCentsPB
            // 
            this.tenCentsPB.Image = ((System.Drawing.Image)(resources.GetObject("tenCentsPB.Image")));
            this.tenCentsPB.Location = new System.Drawing.Point(139, 47);
            this.tenCentsPB.Name = "tenCentsPB";
            this.tenCentsPB.Size = new System.Drawing.Size(123, 188);
            this.tenCentsPB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.tenCentsPB.TabIndex = 2;
            this.tenCentsPB.TabStop = false;
            this.tenCentsPB.Click += new System.EventHandler(this.tenCentsPB_Click);
            // 
            // fiftyCentsPB
            // 
            this.fiftyCentsPB.Image = ((System.Drawing.Image)(resources.GetObject("fiftyCentsPB.Image")));
            this.fiftyCentsPB.Location = new System.Drawing.Point(139, 241);
            this.fiftyCentsPB.Name = "fiftyCentsPB";
            this.fiftyCentsPB.Size = new System.Drawing.Size(123, 187);
            this.fiftyCentsPB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.fiftyCentsPB.TabIndex = 3;
            this.fiftyCentsPB.TabStop = false;
            this.fiftyCentsPB.Click += new System.EventHandler(this.fiftyCentsPB_Click);
            // 
            // instructiionLB
            // 
            this.instructiionLB.AutoSize = true;
            this.instructiionLB.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.instructiionLB.Location = new System.Drawing.Point(54, 9);
            this.instructiionLB.Name = "instructiionLB";
            this.instructiionLB.Size = new System.Drawing.Size(160, 20);
            this.instructiionLB.TabIndex = 4;
            this.instructiionLB.Text = "CLICK THE COINS";
            this.instructiionLB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // outputInstructionLB
            // 
            this.outputInstructionLB.AutoSize = true;
            this.outputInstructionLB.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.outputInstructionLB.Location = new System.Drawing.Point(306, 163);
            this.outputInstructionLB.Name = "outputInstructionLB";
            this.outputInstructionLB.Size = new System.Drawing.Size(64, 20);
            this.outputInstructionLB.TabIndex = 5;
            this.outputInstructionLB.Text = "TOTAL";
            // 
            // totalLB
            // 
            this.totalLB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalLB.Location = new System.Drawing.Point(283, 212);
            this.totalLB.Name = "totalLB";
            this.totalLB.Size = new System.Drawing.Size(129, 23);
            this.totalLB.TabIndex = 6;
            this.totalLB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.totalLB.Click += new System.EventHandler(this.totalLB_Click);
            // 
            // exitBTN
            // 
            this.exitBTN.Location = new System.Drawing.Point(310, 388);
            this.exitBTN.Name = "exitBTN";
            this.exitBTN.Size = new System.Drawing.Size(75, 23);
            this.exitBTN.TabIndex = 7;
            this.exitBTN.Text = "EXIT";
            this.exitBTN.UseVisualStyleBackColor = true;
            this.exitBTN.Click += new System.EventHandler(this.exitBTN_Click);
            // 
            // ChangeCounter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(426, 433);
            this.Controls.Add(this.exitBTN);
            this.Controls.Add(this.totalLB);
            this.Controls.Add(this.outputInstructionLB);
            this.Controls.Add(this.instructiionLB);
            this.Controls.Add(this.fiftyCentsPB);
            this.Controls.Add(this.tenCentsPB);
            this.Controls.Add(this.twentyFiveCentsPB);
            this.Controls.Add(this.fiveCentsPB);
            this.Name = "ChangeCounter";
            this.Text = "Change Counter";
            this.Load += new System.EventHandler(this.ChangeCounter_Load);
            ((System.ComponentModel.ISupportInitialize)(this.fiveCentsPB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.twentyFiveCentsPB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tenCentsPB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fiftyCentsPB)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox fiveCentsPB;
        private System.Windows.Forms.PictureBox twentyFiveCentsPB;
        private System.Windows.Forms.PictureBox tenCentsPB;
        private System.Windows.Forms.PictureBox fiftyCentsPB;
        private System.Windows.Forms.Label instructiionLB;
        private System.Windows.Forms.Label outputInstructionLB;
        private System.Windows.Forms.Label totalLB;
        private System.Windows.Forms.Button exitBTN;
    }
}

