﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tutorial3_5ChangeCounter
{
    public partial class ChangeCounter : Form
    {
        // CONSTANT FIELDS
        const decimal FIVE_CENTS_VALUE = 0.05m;
        const decimal TEN_CENTS_VALUE = 0.10m;
        const decimal TWENTY_FIVE_CENTS_VALUE = 0.25m;
        const decimal FIFTY_CENTS_VALUE = 0.5m;

        //field variable to hold the total.
        //initialized with 0m;
        private decimal total = 0m;


        public ChangeCounter()
        {
            InitializeComponent();
        }

        private void ChangeCounter_Load(object sender, EventArgs e)
        {

        }

        private void fiveCentsPB_Click(object sender, EventArgs e)
        {
            // add the value of 5 cents to the total
            total += FIVE_CENTS_VALUE;

            //DISPLAY THE TOTAL, FORMATED AS CURRENCY.
            totalLB.Text = total.ToString("c");
        }

        private void tenCentsPB_Click(object sender, EventArgs e)
        {
            //add the value of 10 cents to the total
            total += TEN_CENTS_VALUE;
            //display the total, formatted as currency
            totalLB.Text = total.ToString("c");

        
        }

        private void twentyFiveCentsPB_Click(object sender, EventArgs e)
        {
            //add the value of 25 cents to the total
            total += TWENTY_FIVE_CENTS_VALUE;
            //display the total, formatted as currency
            totalLB.Text = total.ToString("c");

        
        }

        private void fiftyCentsPB_Click(object sender, EventArgs e)
        {
            //add the value of 50 cents to the total.
            total += FIFTY_CENTS_VALUE;
            //display the total, formatted as currency.
            totalLB.Text = total.ToString("c");

        }

        private void totalLB_Click(object sender, EventArgs e)
        {

        }

        private void exitBTN_Click(object sender, EventArgs e)
        {
            //close the form
            this.Close();
        }
    }
}
